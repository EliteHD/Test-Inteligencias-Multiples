﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Encuesta1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Encuesta1));
            this.r1 = new System.Windows.Forms.CheckBox();
            this.r2 = new System.Windows.Forms.CheckBox();
            this.r3 = new System.Windows.Forms.CheckBox();
            this.r4 = new System.Windows.Forms.CheckBox();
            this.r5 = new System.Windows.Forms.CheckBox();
            this.r10 = new System.Windows.Forms.CheckBox();
            this.r9 = new System.Windows.Forms.CheckBox();
            this.r8 = new System.Windows.Forms.CheckBox();
            this.r7 = new System.Windows.Forms.CheckBox();
            this.r6 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.botonsiguiente = new MaterialSkin.Controls.MaterialRaisedButton();
            this.txtinfo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // r1
            // 
            this.r1.AutoSize = true;
            this.r1.BackColor = System.Drawing.Color.Transparent;
            this.r1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r1.Location = new System.Drawing.Point(54, 137);
            this.r1.Name = "r1";
            this.r1.Size = new System.Drawing.Size(306, 24);
            this.r1.TabIndex = 0;
            this.r1.Text = "Los libros son muy importantes para mi.";
            this.r1.UseVisualStyleBackColor = false;
            // 
            // r2
            // 
            this.r2.AutoSize = true;
            this.r2.BackColor = System.Drawing.Color.Transparent;
            this.r2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r2.Location = new System.Drawing.Point(54, 182);
            this.r2.Name = "r2";
            this.r2.Size = new System.Drawing.Size(480, 24);
            this.r2.TabIndex = 1;
            this.r2.Text = "Oigo las palabras en mi mente antes de leer, hablar o escribirlas.";
            this.r2.UseVisualStyleBackColor = false;
            // 
            // r3
            // 
            this.r3.AutoSize = true;
            this.r3.BackColor = System.Drawing.Color.Transparent;
            this.r3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r3.Location = new System.Drawing.Point(54, 231);
            this.r3.Name = "r3";
            this.r3.Size = new System.Drawing.Size(581, 24);
            this.r3.TabIndex = 2;
            this.r3.Text = "Me aportan más la radio o unas cintas grabada que la televisupi o las películas.";
            this.r3.UseVisualStyleBackColor = false;
            // 
            // r4
            // 
            this.r4.AutoSize = true;
            this.r4.BackColor = System.Drawing.Color.Transparent;
            this.r4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r4.Location = new System.Drawing.Point(54, 278);
            this.r4.Name = "r4";
            this.r4.Size = new System.Drawing.Size(594, 24);
            this.r4.TabIndex = 3;
            this.r4.Text = "Me gustan los juegos de palabras como el Scrabble, el Anagrams o el Password.";
            this.r4.UseVisualStyleBackColor = false;
            // 
            // r5
            // 
            this.r5.AutoSize = true;
            this.r5.BackColor = System.Drawing.Color.Transparent;
            this.r5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r5.Location = new System.Drawing.Point(54, 319);
            this.r5.Name = "r5";
            this.r5.Size = new System.Drawing.Size(777, 24);
            this.r5.TabIndex = 4;
            this.r5.Text = "Me gustra entretenerme o entretener a los demás con trabalenguas, rimas absurdas " +
    "o juegos de palabras.";
            this.r5.UseVisualStyleBackColor = false;
            // 
            // r10
            // 
            this.r10.AutoSize = true;
            this.r10.BackColor = System.Drawing.Color.Transparent;
            this.r10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r10.Location = new System.Drawing.Point(54, 550);
            this.r10.Name = "r10";
            this.r10.Size = new System.Drawing.Size(466, 24);
            this.r10.TabIndex = 9;
            this.r10.Text = "Recientemente he escrito algo de lo que estoy especialmente.";
            this.r10.UseVisualStyleBackColor = false;
            // 
            // r9
            // 
            this.r9.AutoSize = true;
            this.r9.BackColor = System.Drawing.Color.Transparent;
            this.r9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r9.Location = new System.Drawing.Point(54, 509);
            this.r9.Name = "r9";
            this.r9.Size = new System.Drawing.Size(602, 24);
            this.r9.TabIndex = 8;
            this.r9.Text = "Mi conversación incluye referencias frecuentes a datos que he léido o escuchado.";
            this.r9.UseVisualStyleBackColor = false;
            // 
            // r8
            // 
            this.r8.AutoSize = true;
            this.r8.BackColor = System.Drawing.Color.Transparent;
            this.r8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r8.Location = new System.Drawing.Point(54, 462);
            this.r8.Name = "r8";
            this.r8.Size = new System.Drawing.Size(800, 24);
            this.r8.TabIndex = 7;
            this.r8.Text = "Aprender a hablar o leer otra lengua (inglés, francés, o alemán, o algun otro) me" +
    " resulta relativamente sencillo.";
            this.r8.UseVisualStyleBackColor = false;
            // 
            // r7
            // 
            this.r7.AutoSize = true;
            this.r7.BackColor = System.Drawing.Color.Transparent;
            this.r7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r7.Location = new System.Drawing.Point(54, 413);
            this.r7.Name = "r7";
            this.r7.Size = new System.Drawing.Size(876, 24);
            this.r7.TabIndex = 6;
            this.r7.Text = "En el cole asimilaba mejor la lengua y la literatura, las ciencias sociales y la " +
    "historia que las mates y las ciencias naturales.";
            this.r7.UseVisualStyleBackColor = false;
            this.r7.CheckedChanged += new System.EventHandler(this.r7_CheckedChanged);
            // 
            // r6
            // 
            this.r6.AutoSize = true;
            this.r6.BackColor = System.Drawing.Color.Transparent;
            this.r6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r6.Location = new System.Drawing.Point(54, 368);
            this.r6.Name = "r6";
            this.r6.Size = new System.Drawing.Size(858, 24);
            this.r6.TabIndex = 5;
            this.r6.Text = "En ocaciones, algunas personas me piden que les explique el significado de las pa" +
    "labras que utilizo (escirtas u orales).";
            this.r6.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(581, 80);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(395, 300);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(383, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Seleccione la casilla si es el caso.";
            // 
            // botonsiguiente
            // 
            this.botonsiguiente.Depth = 0;
            this.botonsiguiente.Location = new System.Drawing.Point(777, 565);
            this.botonsiguiente.MouseState = MaterialSkin.MouseState.HOVER;
            this.botonsiguiente.Name = "botonsiguiente";
            this.botonsiguiente.Primary = true;
            this.botonsiguiente.Size = new System.Drawing.Size(186, 52);
            this.botonsiguiente.TabIndex = 19;
            this.botonsiguiente.Text = "Siguiente Inteligencia";
            this.botonsiguiente.UseVisualStyleBackColor = true;
            this.botonsiguiente.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // txtinfo
            // 
            this.txtinfo.AutoSize = true;
            this.txtinfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfo.Location = new System.Drawing.Point(774, 536);
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(0, 13);
            this.txtinfo.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Josias Dominguez Hernández";
            // 
            // Encuesta1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 639);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtinfo);
            this.Controls.Add(this.botonsiguiente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.r10);
            this.Controls.Add(this.r9);
            this.Controls.Add(this.r8);
            this.Controls.Add(this.r7);
            this.Controls.Add(this.r6);
            this.Controls.Add(this.r5);
            this.Controls.Add(this.r4);
            this.Controls.Add(this.r3);
            this.Controls.Add(this.r2);
            this.Controls.Add(this.r1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Encuesta1";
            this.Text = "Inteligencia verbal lingüistica";
            this.Load += new System.EventHandler(this.Encuesta1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox r1;
        private System.Windows.Forms.CheckBox r2;
        private System.Windows.Forms.CheckBox r3;
        private System.Windows.Forms.CheckBox r4;
        private System.Windows.Forms.CheckBox r5;
        private System.Windows.Forms.CheckBox r10;
        private System.Windows.Forms.CheckBox r9;
        private System.Windows.Forms.CheckBox r8;
        private System.Windows.Forms.CheckBox r7;
        private System.Windows.Forms.CheckBox r6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private MaterialSkin.Controls.MaterialRaisedButton botonsiguiente;
        private System.Windows.Forms.Label txtinfo;
        private System.Windows.Forms.Label label1;
    }
}