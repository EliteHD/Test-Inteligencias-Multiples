﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Encuesta1 : MaterialSkin.Controls.MaterialForm
    {
        int resultados1 = 0;
        public Encuesta1(int matricula)
        {
            InitializeComponent();
            this.matricula = matricula;

        }
        int matricula;


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Encuesta1_Load(object sender, EventArgs e)
        {
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            if(r1.Checked == true)
            {
                resultados1 += 1;
            }
            if (r2.Checked == true)
            {
                resultados1 += 1;
            }
            if (r3.Checked == true)
            {
                resultados1 += 1;
            }
            if (r4.Checked == true)
            {
                resultados1 += 1;
            }
            if (r5.Checked == true)
            {
                resultados1 += 1;
            }
            if (r6.Checked == true)
            {
                resultados1 += 1;
            }
            if (r7.Checked == true)
            {
                resultados1 += 1;
            }
            if (r8.Checked == true)
            {
                resultados1 += 1;
            }
            if (r9.Checked == true)
            {
                resultados1 += 1;
            }
            if (r10.Checked == true)
            {
                resultados1 += 1;
            }
            if(r1.Checked == false && r2.Checked == false && r3.Checked == false && r4.Checked == false && r5.Checked == false && r6.Checked == false && r7.Checked == false && r8.Checked == false && r9.Checked == false && r10.Checked == false)
            {
                MessageBox.Show("Talvez no sea lo tuyo esta inteligencia, no?", "Información, antes de avanzar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            
            Seccion1 s1 = new Seccion1();
            s1.Matricula = matricula;
            s1.p1_s1 = r1.Checked;
            s1.p2_s1 = r2.Checked;
            s1.p3_s1 = r3.Checked;
            s1.p4_s1 = r4.Checked;
            s1.p5_s1 = r5.Checked;
            s1.p6_s1 = r6.Checked;
            s1.p7_s1 = r7.Checked;
            s1.p8_s1 = r8.Checked;
            s1.p9_s1 = r9.Checked;
            s1.p10_s1 = r10.Checked;

            int resultado = EncuestadoDAO.Seccion1(s1);
            if (resultado > 0)
            {
                MessageBox.Show("Perfecto 1/8!!", "Avance", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
            Encuesta2 encuesta2 = new Encuesta2(matricula,resultados1);
            ResultadosTest resultadoss = new ResultadosTest(resultados1,0,0,0,0,0,0,0,matricula);
            encuesta2.Show();
            this.Hide();



        }

        private void r7_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
