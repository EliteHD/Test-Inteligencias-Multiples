﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Encuesta2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Encuesta2));
            this.txtinfo = new System.Windows.Forms.Label();
            this.botonsiguiente = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label3 = new System.Windows.Forms.Label();
            this.r210 = new System.Windows.Forms.CheckBox();
            this.r29 = new System.Windows.Forms.CheckBox();
            this.r28 = new System.Windows.Forms.CheckBox();
            this.r27 = new System.Windows.Forms.CheckBox();
            this.r26 = new System.Windows.Forms.CheckBox();
            this.r25 = new System.Windows.Forms.CheckBox();
            this.r24 = new System.Windows.Forms.CheckBox();
            this.r23 = new System.Windows.Forms.CheckBox();
            this.r22 = new System.Windows.Forms.CheckBox();
            this.r21 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtinfo
            // 
            this.txtinfo.AutoSize = true;
            this.txtinfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfo.Location = new System.Drawing.Point(772, 535);
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(0, 13);
            this.txtinfo.TabIndex = 34;
            // 
            // botonsiguiente
            // 
            this.botonsiguiente.Depth = 0;
            this.botonsiguiente.Location = new System.Drawing.Point(785, 615);
            this.botonsiguiente.MouseState = MaterialSkin.MouseState.HOVER;
            this.botonsiguiente.Name = "botonsiguiente";
            this.botonsiguiente.Primary = true;
            this.botonsiguiente.Size = new System.Drawing.Size(186, 52);
            this.botonsiguiente.TabIndex = 33;
            this.botonsiguiente.Text = "Siguiente Inteligencia";
            this.botonsiguiente.UseVisualStyleBackColor = true;
            this.botonsiguiente.Click += new System.EventHandler(this.botonsiguiente_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(381, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "Seleccione la casilla si es el caso.";
            // 
            // r210
            // 
            this.r210.AutoSize = true;
            this.r210.BackColor = System.Drawing.Color.Transparent;
            this.r210.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r210.Location = new System.Drawing.Point(52, 549);
            this.r210.Name = "r210";
            this.r210.Size = new System.Drawing.Size(842, 24);
            this.r210.TabIndex = 30;
            this.r210.Text = "Me siento más comodo cuando las cosas están medidas, categorizarlas, analizadas o" +
    " cuantificadas de algún modo.";
            this.r210.UseVisualStyleBackColor = false;
            // 
            // r29
            // 
            this.r29.AutoSize = true;
            this.r29.BackColor = System.Drawing.Color.Transparent;
            this.r29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r29.Location = new System.Drawing.Point(52, 508);
            this.r29.Name = "r29";
            this.r29.Size = new System.Drawing.Size(645, 24);
            this.r29.TabIndex = 29;
            this.r29.Text = "Me gusta detectar lógicos en las cosas que la gente dice y hace en casa o en el t" +
    "rabajo.";
            this.r29.UseVisualStyleBackColor = false;
            // 
            // r28
            // 
            this.r28.AutoSize = true;
            this.r28.BackColor = System.Drawing.Color.Transparent;
            this.r28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r28.Location = new System.Drawing.Point(52, 461);
            this.r28.Name = "r28";
            this.r28.Size = new System.Drawing.Size(590, 24);
            this.r28.TabIndex = 28;
            this.r28.Text = "En ocasiones pienso en conceptos claros, abstractos, sin palabras ni imágenes.";
            this.r28.UseVisualStyleBackColor = false;
            // 
            // r27
            // 
            this.r27.AutoSize = true;
            this.r27.BackColor = System.Drawing.Color.Transparent;
            this.r27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r27.Location = new System.Drawing.Point(52, 412);
            this.r27.Name = "r27";
            this.r27.Size = new System.Drawing.Size(375, 24);
            this.r27.TabIndex = 27;
            this.r27.Text = "Creo que casi todo tiene una explicación racional.";
            this.r27.UseVisualStyleBackColor = false;
            // 
            // r26
            // 
            this.r26.AutoSize = true;
            this.r26.BackColor = System.Drawing.Color.Transparent;
            this.r26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r26.Location = new System.Drawing.Point(52, 367);
            this.r26.Name = "r26";
            this.r26.Size = new System.Drawing.Size(285, 24);
            this.r26.TabIndex = 26;
            this.r26.Text = "Me interesan los avances científicos.";
            this.r26.UseVisualStyleBackColor = false;
            // 
            // r25
            // 
            this.r25.AutoSize = true;
            this.r25.BackColor = System.Drawing.Color.Transparent;
            this.r25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r25.Location = new System.Drawing.Point(52, 318);
            this.r25.Name = "r25";
            this.r25.Size = new System.Drawing.Size(540, 24);
            this.r25.TabIndex = 25;
            this.r25.Text = "Mi mente busca patrones, regularidad o secuencias lógicas en las cosas.";
            this.r25.UseVisualStyleBackColor = false;
            // 
            // r24
            // 
            this.r24.AutoSize = true;
            this.r24.BackColor = System.Drawing.Color.Transparent;
            this.r24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r24.Location = new System.Drawing.Point(52, 277);
            this.r24.Name = "r24";
            this.r24.Size = new System.Drawing.Size(531, 24);
            this.r24.TabIndex = 24;
            this.r24.Text = "Me gusta realizar pequeños experimentos del tipo <¿Qué pasaría si...?>";
            this.r24.UseVisualStyleBackColor = false;
            // 
            // r23
            // 
            this.r23.AutoSize = true;
            this.r23.BackColor = System.Drawing.Color.Transparent;
            this.r23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r23.Location = new System.Drawing.Point(52, 230);
            this.r23.Name = "r23";
            this.r23.Size = new System.Drawing.Size(543, 24);
            this.r23.TabIndex = 23;
            this.r23.Text = "Me gustan los juegos o los acertijos que requieren un pensamiento lógico";
            this.r23.UseVisualStyleBackColor = false;
            // 
            // r22
            // 
            this.r22.AutoSize = true;
            this.r22.BackColor = System.Drawing.Color.Transparent;
            this.r22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r22.Location = new System.Drawing.Point(52, 181);
            this.r22.Name = "r22";
            this.r22.Size = new System.Drawing.Size(645, 24);
            this.r22.TabIndex = 22;
            this.r22.Text = "Las matemáticas y/o las ciencias figuraban entre mis asignaturas favoritas en el " +
    "colegio.";
            this.r22.UseVisualStyleBackColor = false;
            // 
            // r21
            // 
            this.r21.AutoSize = true;
            this.r21.BackColor = System.Drawing.Color.Transparent;
            this.r21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r21.Location = new System.Drawing.Point(52, 136);
            this.r21.Name = "r21";
            this.r21.Size = new System.Drawing.Size(464, 24);
            this.r21.TabIndex = 21;
            this.r21.Text = "Soy capaz de calcular operaciones mentalmente sin esfuerzo.";
            this.r21.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(678, 230);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(260, 233);
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(49, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 36;
            this.label1.Text = "Josias Dominguez Hernández";
            // 
            // Encuesta2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 694);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtinfo);
            this.Controls.Add(this.botonsiguiente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.r210);
            this.Controls.Add(this.r29);
            this.Controls.Add(this.r28);
            this.Controls.Add(this.r27);
            this.Controls.Add(this.r26);
            this.Controls.Add(this.r25);
            this.Controls.Add(this.r24);
            this.Controls.Add(this.r23);
            this.Controls.Add(this.r22);
            this.Controls.Add(this.r21);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Encuesta2";
            this.Text = "Inteligencia Lógico-Matemático";
            this.Load += new System.EventHandler(this.Encuesta2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtinfo;
        private MaterialSkin.Controls.MaterialRaisedButton botonsiguiente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox r210;
        private System.Windows.Forms.CheckBox r29;
        private System.Windows.Forms.CheckBox r28;
        private System.Windows.Forms.CheckBox r27;
        private System.Windows.Forms.CheckBox r26;
        private System.Windows.Forms.CheckBox r25;
        private System.Windows.Forms.CheckBox r24;
        private System.Windows.Forms.CheckBox r23;
        private System.Windows.Forms.CheckBox r22;
        private System.Windows.Forms.CheckBox r21;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}