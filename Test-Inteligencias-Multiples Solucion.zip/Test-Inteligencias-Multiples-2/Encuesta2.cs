﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Encuesta2 : MaterialSkin.Controls.MaterialForm
    {
        int resultados2=0;
        public Encuesta2(int matricula,int resultados1)
        {
            InitializeComponent();
            this.matricula = matricula;
            this.resultados1 = resultados1;
        }
        int matricula;
        int resultados1;

        private void Encuesta2_Load(object sender, EventArgs e)
        {

        }

        private void botonsiguiente_Click(object sender, EventArgs e)
        {
            if (r21.Checked == true)
            {
                resultados2 += 1;
            }
            if (r22.Checked == true)
            {
                resultados2 += 1;
            }
            if (r23.Checked == true)
            {
                resultados2 += 1;
            }
            if (r24.Checked == true)
            {
                resultados2 += 1;
            }
            if (r25.Checked == true)
            {
                resultados2 += 1;
            }
            if (r26.Checked == true)
            {
                resultados2 += 1;
            }
            if (r27.Checked == true)
            {
                resultados2 += 1;
            }
            if (r28.Checked == true)
            {
                resultados2 += 1;
            }
            if (r29.Checked == true)
            {
                resultados2 += 1;
            }
            if (r210.Checked == true)
            {
                resultados2 += 1;
            }
            if (r21.Checked == false && r22.Checked == false && r23.Checked == false && r24.Checked == false && r25.Checked == false && r26.Checked == false && r27.Checked == false && r28.Checked == false && r29.Checked == false && r210.Checked == false)
            {
                MessageBox.Show("Talvez no sea lo tuyo esta inteligencia, no?", "Información, antes de avanzar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            Seccion2 s2 = new Seccion2();
            s2.Matricula = matricula;
            s2.p1_s2 = r21.Checked;
            s2.p2_s2 = r22.Checked;
            s2.p3_s2 = r23.Checked;
            s2.p4_s2 = r24.Checked;
            s2.p5_s2 = r25.Checked;
            s2.p6_s2 = r26.Checked;
            s2.p7_s2 = r27.Checked;
            s2.p8_s2 = r28.Checked;
            s2.p9_s2 = r29.Checked;
            s2.p10_s2 = r210.Checked;


            int resultado = EncuestadoDAO.Seccion2(s2);
            if (resultado > 0)
            {
                MessageBox.Show("Perfecto 2/8!!", "Avance", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }

            Encuesta3 encuesta3 = new Encuesta3(matricula,resultados1,resultados2);
            ResultadosTest resultadoss = new ResultadosTest(resultados1,resultados2,0,0,0,0,0,0,matricula);
            encuesta3.Show();
            this.Hide();
        }
    }
}
