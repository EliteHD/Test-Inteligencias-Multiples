﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Encuesta3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Encuesta3));
            this.txtinfo = new System.Windows.Forms.Label();
            this.botonsiguiente = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label3 = new System.Windows.Forms.Label();
            this.r310 = new System.Windows.Forms.CheckBox();
            this.r39 = new System.Windows.Forms.CheckBox();
            this.r38 = new System.Windows.Forms.CheckBox();
            this.r37 = new System.Windows.Forms.CheckBox();
            this.r36 = new System.Windows.Forms.CheckBox();
            this.r35 = new System.Windows.Forms.CheckBox();
            this.r34 = new System.Windows.Forms.CheckBox();
            this.r33 = new System.Windows.Forms.CheckBox();
            this.r32 = new System.Windows.Forms.CheckBox();
            this.r31 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtinfo
            // 
            this.txtinfo.AutoSize = true;
            this.txtinfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfo.Location = new System.Drawing.Point(759, 544);
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(0, 13);
            this.txtinfo.TabIndex = 34;
            // 
            // botonsiguiente
            // 
            this.botonsiguiente.Depth = 0;
            this.botonsiguiente.Location = new System.Drawing.Point(762, 573);
            this.botonsiguiente.MouseState = MaterialSkin.MouseState.HOVER;
            this.botonsiguiente.Name = "botonsiguiente";
            this.botonsiguiente.Primary = true;
            this.botonsiguiente.Size = new System.Drawing.Size(186, 52);
            this.botonsiguiente.TabIndex = 33;
            this.botonsiguiente.Text = "Siguiente Inteligencia";
            this.botonsiguiente.UseVisualStyleBackColor = true;
            this.botonsiguiente.Click += new System.EventHandler(this.botonsiguiente_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(368, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "Seleccione la casilla si es el caso.";
            // 
            // r310
            // 
            this.r310.AutoSize = true;
            this.r310.BackColor = System.Drawing.Color.Transparent;
            this.r310.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r310.Location = new System.Drawing.Point(39, 558);
            this.r310.Name = "r310";
            this.r310.Size = new System.Drawing.Size(419, 24);
            this.r310.TabIndex = 30;
            this.r310.Text = "Prefiero el material de lectura con muchas ilustraciones.";
            this.r310.UseVisualStyleBackColor = false;
            // 
            // r39
            // 
            this.r39.AutoSize = true;
            this.r39.BackColor = System.Drawing.Color.Transparent;
            this.r39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r39.Location = new System.Drawing.Point(39, 517);
            this.r39.Name = "r39";
            this.r39.Size = new System.Drawing.Size(676, 24);
            this.r39.TabIndex = 29;
            this.r39.Text = "Me puedo imaginar sin ningun esfuerzo el aspecto que tendria las cosas vistas des" +
    "de arriba.";
            this.r39.UseVisualStyleBackColor = false;
            // 
            // r38
            // 
            this.r38.AutoSize = true;
            this.r38.BackColor = System.Drawing.Color.Transparent;
            this.r38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r38.Location = new System.Drawing.Point(39, 470);
            this.r38.Name = "r38";
            this.r38.Size = new System.Drawing.Size(456, 24);
            this.r38.TabIndex = 28;
            this.r38.Text = "En el colegio me costaba menos la geometría que el álgebra.";
            this.r38.UseVisualStyleBackColor = false;
            // 
            // r37
            // 
            this.r37.AutoSize = true;
            this.r37.BackColor = System.Drawing.Color.Transparent;
            this.r37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r37.Location = new System.Drawing.Point(39, 421);
            this.r37.Name = "r37";
            this.r37.Size = new System.Drawing.Size(244, 24);
            this.r37.TabIndex = 27;
            this.r37.Text = "Me gusta dibujar o garabatear.";
            this.r37.UseVisualStyleBackColor = false;
            // 
            // r36
            // 
            this.r36.AutoSize = true;
            this.r36.BackColor = System.Drawing.Color.Transparent;
            this.r36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r36.Location = new System.Drawing.Point(39, 376);
            this.r36.Name = "r36";
            this.r36.Size = new System.Drawing.Size(467, 24);
            this.r36.TabIndex = 26;
            this.r36.Text = "En general, soy capaz de orientarme en un lugar desconocido.";
            this.r36.UseVisualStyleBackColor = false;
            // 
            // r35
            // 
            this.r35.AutoSize = true;
            this.r35.BackColor = System.Drawing.Color.Transparent;
            this.r35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r35.Location = new System.Drawing.Point(39, 327);
            this.r35.Name = "r35";
            this.r35.Size = new System.Drawing.Size(318, 24);
            this.r35.TabIndex = 25;
            this.r35.Text = "Por la noche tengo sueños muy intensos.";
            this.r35.UseVisualStyleBackColor = false;
            // 
            // r34
            // 
            this.r34.AutoSize = true;
            this.r34.BackColor = System.Drawing.Color.Transparent;
            this.r34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r34.Location = new System.Drawing.Point(39, 286);
            this.r34.Name = "r34";
            this.r34.Size = new System.Drawing.Size(524, 24);
            this.r34.TabIndex = 24;
            this.r34.Text = "Me gustan los rompecabezas, los laberintos y dem¿as juegos visuales.";
            this.r34.UseVisualStyleBackColor = false;
            // 
            // r33
            // 
            this.r33.AutoSize = true;
            this.r33.BackColor = System.Drawing.Color.Transparent;
            this.r33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r33.Location = new System.Drawing.Point(39, 239);
            this.r33.Name = "r33";
            this.r33.Size = new System.Drawing.Size(733, 24);
            this.r33.TabIndex = 23;
            this.r33.Text = "Habitualmente utilizo una cámara de fotos o una videocámara para captar lo que ve" +
    "o a mi alrededor.";
            this.r33.UseVisualStyleBackColor = false;
            // 
            // r32
            // 
            this.r32.AutoSize = true;
            this.r32.BackColor = System.Drawing.Color.Transparent;
            this.r32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r32.Location = new System.Drawing.Point(39, 190);
            this.r32.Name = "r32";
            this.r32.Size = new System.Drawing.Size(175, 24);
            this.r32.TabIndex = 22;
            this.r32.Text = "Soy sensible al color.";
            this.r32.UseVisualStyleBackColor = false;
            // 
            // r31
            // 
            this.r31.AutoSize = true;
            this.r31.BackColor = System.Drawing.Color.Transparent;
            this.r31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r31.Location = new System.Drawing.Point(39, 145);
            this.r31.Name = "r31";
            this.r31.Size = new System.Drawing.Size(428, 24);
            this.r31.TabIndex = 21;
            this.r31.Text = "Cuando cierro los ojos percibo imágenes visuales claras.-";
            this.r31.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(650, 172);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(312, 339);
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 36;
            this.label1.Text = "Josias Dominguez Hernández";
            // 
            // Encuesta3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 639);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtinfo);
            this.Controls.Add(this.botonsiguiente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.r310);
            this.Controls.Add(this.r39);
            this.Controls.Add(this.r38);
            this.Controls.Add(this.r37);
            this.Controls.Add(this.r36);
            this.Controls.Add(this.r35);
            this.Controls.Add(this.r34);
            this.Controls.Add(this.r33);
            this.Controls.Add(this.r32);
            this.Controls.Add(this.r31);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Encuesta3";
            this.Text = "Inteligencia visio-espacial";
            this.Load += new System.EventHandler(this.Encuesta3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtinfo;
        private MaterialSkin.Controls.MaterialRaisedButton botonsiguiente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox r310;
        private System.Windows.Forms.CheckBox r39;
        private System.Windows.Forms.CheckBox r38;
        private System.Windows.Forms.CheckBox r37;
        private System.Windows.Forms.CheckBox r36;
        private System.Windows.Forms.CheckBox r35;
        private System.Windows.Forms.CheckBox r34;
        private System.Windows.Forms.CheckBox r33;
        private System.Windows.Forms.CheckBox r32;
        private System.Windows.Forms.CheckBox r31;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}