﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    
    public partial class Encuesta3 : MaterialSkin.Controls.MaterialForm
    {
        int resultados3=0;

        public Encuesta3(int matricula,int resultados1, int resultados2)
        {
            InitializeComponent();
            this.matricula = matricula;
            this.resultados1 = resultados1;
            this.resultados2 = resultados2;
        }
        int matricula;
        int resultados1;
        int resultados2;

        private void Encuesta3_Load(object sender, EventArgs e)
        {

        }

        private void botonsiguiente_Click(object sender, EventArgs e)
        {
            if (r31.Checked == true)
            {
                resultados3 += 1;
            }
            if (r32.Checked == true)
            {
                resultados3 += 1;
            }
            if (r33.Checked == true)
            {
                resultados3 += 1;
            }
            if (r34.Checked == true)
            {
                resultados3 += 1;
            }
            if (r35.Checked == true)
            {
                resultados3 += 1;
            }
            if (r36.Checked == true)
            {
                resultados3 += 1;
            }
            if (r37.Checked == true)
            {
                resultados3 += 1;
            }
            if (r38.Checked == true)
            {
                resultados3 += 1;
            }
            if (r39.Checked == true)
            {
                resultados3 += 1;
            }
            if (r310.Checked == true)
            {
                resultados3 += 1;
            }
            if (r31.Checked == false && r32.Checked == false && r33.Checked == false && r34.Checked == false && r35.Checked == false && r36.Checked == false && r37.Checked == false && r38.Checked == false && r39.Checked == false && r310.Checked == false)
            {
                MessageBox.Show("Talvez no sea lo tuyo esta inteligencia, no?", "Información, antes de avanzar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            Seccion3 s3 = new Seccion3();
            s3.Matricula = matricula;
            s3.p1_s3 = r31.Checked;
            s3.p2_s3 = r32.Checked;
            s3.p3_s3 = r33.Checked;
            s3.p4_s3 = r34.Checked;
            s3.p5_s3 = r35.Checked;
            s3.p6_s3 = r36.Checked;
            s3.p7_s3 = r37.Checked;
            s3.p8_s3 = r38.Checked;
            s3.p9_s3 = r39.Checked;
            s3.p10_s3 = r310.Checked;


            int resultado = EncuestadoDAO.Seccion3(s3);
            if (resultado > 0)
            {
                MessageBox.Show("Perfecto 3/8!!", "Avance", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
            ResultadosTest resultadoss = new ResultadosTest(resultados1, resultados2, resultados3, 0, 0, 0, 0, 0,matricula);
            Encuesta4 encuesta4 = new Encuesta4(matricula,resultados1,resultados2,resultados3);

            encuesta4.Show();
            this.Hide();
        }
    }
}
