﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Encuesta4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Encuesta4));
            this.txtinfo = new System.Windows.Forms.Label();
            this.botonsiguiente = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label3 = new System.Windows.Forms.Label();
            this.r410 = new System.Windows.Forms.CheckBox();
            this.r49 = new System.Windows.Forms.CheckBox();
            this.r48 = new System.Windows.Forms.CheckBox();
            this.r47 = new System.Windows.Forms.CheckBox();
            this.r46 = new System.Windows.Forms.CheckBox();
            this.r45 = new System.Windows.Forms.CheckBox();
            this.r44 = new System.Windows.Forms.CheckBox();
            this.r43 = new System.Windows.Forms.CheckBox();
            this.r42 = new System.Windows.Forms.CheckBox();
            this.r41 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtinfo
            // 
            this.txtinfo.AutoSize = true;
            this.txtinfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfo.Location = new System.Drawing.Point(765, 531);
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(0, 13);
            this.txtinfo.TabIndex = 48;
            // 
            // botonsiguiente
            // 
            this.botonsiguiente.Depth = 0;
            this.botonsiguiente.Location = new System.Drawing.Point(768, 560);
            this.botonsiguiente.MouseState = MaterialSkin.MouseState.HOVER;
            this.botonsiguiente.Name = "botonsiguiente";
            this.botonsiguiente.Primary = true;
            this.botonsiguiente.Size = new System.Drawing.Size(186, 52);
            this.botonsiguiente.TabIndex = 47;
            this.botonsiguiente.Text = "Siguiente Inteligencia";
            this.botonsiguiente.UseVisualStyleBackColor = true;
            this.botonsiguiente.Click += new System.EventHandler(this.botonsiguiente_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(374, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 13);
            this.label3.TabIndex = 46;
            this.label3.Text = "Seleccione la casilla si es el caso.";
            // 
            // r410
            // 
            this.r410.AutoSize = true;
            this.r410.BackColor = System.Drawing.Color.Transparent;
            this.r410.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r410.Location = new System.Drawing.Point(45, 545);
            this.r410.Name = "r410";
            this.r410.Size = new System.Drawing.Size(702, 24);
            this.r410.TabIndex = 45;
            this.r410.Text = "No me basta con leer informacion o ver un video sobre una nueva actividad, necesi" +
    "to practicarla.";
            this.r410.UseVisualStyleBackColor = false;
            // 
            // r49
            // 
            this.r49.AutoSize = true;
            this.r49.BackColor = System.Drawing.Color.Transparent;
            this.r49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r49.Location = new System.Drawing.Point(45, 504);
            this.r49.Name = "r49";
            this.r49.Size = new System.Drawing.Size(422, 24);
            this.r49.TabIndex = 44;
            this.r49.Text = "Creo que soy una persona con una buena coordinación.";
            this.r49.UseVisualStyleBackColor = false;
            // 
            // r48
            // 
            this.r48.AutoSize = true;
            this.r48.BackColor = System.Drawing.Color.Transparent;
            this.r48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r48.Location = new System.Drawing.Point(45, 457);
            this.r48.Name = "r48";
            this.r48.Size = new System.Drawing.Size(431, 24);
            this.r48.TabIndex = 43;
            this.r48.Text = "Creo que soy una o persona con una buena coordinación";
            this.r48.UseVisualStyleBackColor = false;
            // 
            // r47
            // 
            this.r47.AutoSize = true;
            this.r47.BackColor = System.Drawing.Color.Transparent;
            this.r47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r47.Location = new System.Drawing.Point(45, 408);
            this.r47.Name = "r47";
            this.r47.Size = new System.Drawing.Size(398, 24);
            this.r47.TabIndex = 42;
            this.r47.Text = "Necesito tocar las cosas para saber mas sobre ellas.";
            this.r47.UseVisualStyleBackColor = false;
            // 
            // r46
            // 
            this.r46.AutoSize = true;
            this.r46.BackColor = System.Drawing.Color.Transparent;
            this.r46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r46.Location = new System.Drawing.Point(45, 363);
            this.r46.Name = "r46";
            this.r46.Size = new System.Drawing.Size(751, 24);
            this.r46.TabIndex = 41;
            this.r46.Text = "Acostumbro a gesticular mucho o a utilizar otras formas de lenguaje corporal cuan" +
    "do hablo con alguien";
            this.r46.UseVisualStyleBackColor = false;
            // 
            // r45
            // 
            this.r45.AutoSize = true;
            this.r45.BackColor = System.Drawing.Color.Transparent;
            this.r45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r45.Location = new System.Drawing.Point(45, 314);
            this.r45.Name = "r45";
            this.r45.Size = new System.Drawing.Size(344, 24);
            this.r45.TabIndex = 40;
            this.r45.Text = "Me gusta pasar mi tiempo de ocio al aire libre";
            this.r45.UseVisualStyleBackColor = false;
            // 
            // r44
            // 
            this.r44.AutoSize = true;
            this.r44.BackColor = System.Drawing.Color.Transparent;
            this.r44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r44.Location = new System.Drawing.Point(45, 273);
            this.r44.Name = "r44";
            this.r44.Size = new System.Drawing.Size(851, 24);
            this.r44.TabIndex = 39;
            this.r44.Text = "En general, las mejores ideas se me ocurren cuando estoy pensando, corriendo o mi" +
    "entras realizo actividades fisicas.";
            this.r44.UseVisualStyleBackColor = false;
            this.r44.CheckedChanged += new System.EventHandler(this.r4_CheckedChanged);
            // 
            // r43
            // 
            this.r43.AutoSize = true;
            this.r43.BackColor = System.Drawing.Color.Transparent;
            this.r43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r43.Location = new System.Drawing.Point(45, 226);
            this.r43.Name = "r43";
            this.r43.Size = new System.Drawing.Size(805, 24);
            this.r43.TabIndex = 38;
            this.r43.Text = "Me gusta trabajar con las manos en actividades concretas como tejer, carpinteria " +
    "o construcción de maquetas.";
            this.r43.UseVisualStyleBackColor = false;
            // 
            // r42
            // 
            this.r42.AutoSize = true;
            this.r42.BackColor = System.Drawing.Color.Transparent;
            this.r42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r42.Location = new System.Drawing.Point(45, 177);
            this.r42.Name = "r42";
            this.r42.Size = new System.Drawing.Size(354, 24);
            this.r42.TabIndex = 37;
            this.r42.Text = "Me cuesta permanecer quieto durante mucho.";
            this.r42.UseVisualStyleBackColor = false;
            // 
            // r41
            // 
            this.r41.AutoSize = true;
            this.r41.BackColor = System.Drawing.Color.Transparent;
            this.r41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r41.Location = new System.Drawing.Point(45, 132);
            this.r41.Name = "r41";
            this.r41.Size = new System.Drawing.Size(594, 24);
            this.r41.TabIndex = 36;
            this.r41.Text = "Practico al menos de un deporte o algún tipo de actividad fisica de forma regular" +
    ".";
            this.r41.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(768, 314);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 184);
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "Josias Dominguez Hernández";
            // 
            // Encuesta4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 639);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtinfo);
            this.Controls.Add(this.botonsiguiente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.r410);
            this.Controls.Add(this.r49);
            this.Controls.Add(this.r48);
            this.Controls.Add(this.r47);
            this.Controls.Add(this.r46);
            this.Controls.Add(this.r45);
            this.Controls.Add(this.r44);
            this.Controls.Add(this.r43);
            this.Controls.Add(this.r42);
            this.Controls.Add(this.r41);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Encuesta4";
            this.Text = "Inteligencia cinético-corporal";
            this.Load += new System.EventHandler(this.Encuesta4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtinfo;
        private MaterialSkin.Controls.MaterialRaisedButton botonsiguiente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox r410;
        private System.Windows.Forms.CheckBox r49;
        private System.Windows.Forms.CheckBox r48;
        private System.Windows.Forms.CheckBox r47;
        private System.Windows.Forms.CheckBox r46;
        private System.Windows.Forms.CheckBox r45;
        private System.Windows.Forms.CheckBox r44;
        private System.Windows.Forms.CheckBox r43;
        private System.Windows.Forms.CheckBox r42;
        private System.Windows.Forms.CheckBox r41;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}