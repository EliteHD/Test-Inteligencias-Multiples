﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Encuesta4 : MaterialSkin.Controls.MaterialForm
    {
        int resultados4=0;
        public Encuesta4(int matricula,int resultados1, int resultados2, int resultados3)
        {
            InitializeComponent();
            this.matricula = matricula;
            this.resultados1 = resultados1;
            this.resultados2 = resultados2;
            this.resultados3 = resultados3;
        }
        int matricula;
        int resultados1;
        int resultados2;
        int resultados3;

        private void Encuesta4_Load(object sender, EventArgs e)
        {

        }

        private void r4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void botonsiguiente_Click(object sender, EventArgs e)
        {
            if (r41.Checked == true)
            {
                resultados4 += 1;
            }
            if (r42.Checked == true)
            {
                resultados4 += 1;
            }
            if (r43.Checked == true)
            {
                resultados4 += 1;
            }
            if (r44.Checked == true)
            {
                resultados4 += 1;
            }
            if (r45.Checked == true)
            {
                resultados4 += 1;
            }
            if (r46.Checked == true)
            {
                resultados4 += 1;
            }
            if (r47.Checked == true)
            {
                resultados4 += 1;
            }
            if (r48.Checked == true)
            {
                resultados4 += 1;
            }
            if (r49.Checked == true)
            {
                resultados4 += 1;
            }
            if (r410.Checked == true)
            {
                resultados4 += 1;
            }
            if (r41.Checked == false && r42.Checked == false && r43.Checked == false && r44.Checked == false && r45.Checked == false && r46.Checked == false && r47.Checked == false && r48.Checked == false && r49.Checked == false && r410.Checked == false)
            {
                MessageBox.Show("Talvez no sea lo tuyo esta inteligencia, no?", "Información, antes de avanzar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            Seccion4 s4 = new Seccion4();
            s4.Matricula = matricula;
            s4.p1_s4 = r41.Checked;
            s4.p2_s4 = r42.Checked;
            s4.p3_s4 = r43.Checked;
            s4.p4_s4 = r44.Checked;
            s4.p5_s4 = r45.Checked;
            s4.p6_s4 = r46.Checked;
            s4.p7_s4 = r47.Checked;
            s4.p8_s4 = r48.Checked;
            s4.p9_s4 = r49.Checked;
            s4.p10_s4 = r410.Checked;


            int resultado = EncuestadoDAO.Seccion4(s4);
            if (resultado > 0)
            {
                MessageBox.Show("Perfecto 4/8!!", "Avance", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
            ResultadosTest resultadoss = new ResultadosTest(resultados1, resultados2, resultados3, resultados4, 0, 0, 0, 0,matricula);
            Encuesta5 encuesta5 = new Encuesta5(matricula,resultados1,resultados2,resultados3,resultados4);
            encuesta5.Show();
            this.Hide();
        }
    }
}
