﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Encuesta5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Encuesta5));
            this.txtinfo = new System.Windows.Forms.Label();
            this.botonsiguiente = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label3 = new System.Windows.Forms.Label();
            this.r510 = new System.Windows.Forms.CheckBox();
            this.r59 = new System.Windows.Forms.CheckBox();
            this.r58 = new System.Windows.Forms.CheckBox();
            this.r57 = new System.Windows.Forms.CheckBox();
            this.r56 = new System.Windows.Forms.CheckBox();
            this.r55 = new System.Windows.Forms.CheckBox();
            this.r54 = new System.Windows.Forms.CheckBox();
            this.r53 = new System.Windows.Forms.CheckBox();
            this.r52 = new System.Windows.Forms.CheckBox();
            this.r51 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtinfo
            // 
            this.txtinfo.AutoSize = true;
            this.txtinfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfo.Location = new System.Drawing.Point(768, 547);
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(0, 13);
            this.txtinfo.TabIndex = 34;
            // 
            // botonsiguiente
            // 
            this.botonsiguiente.Depth = 0;
            this.botonsiguiente.Location = new System.Drawing.Point(784, 614);
            this.botonsiguiente.MouseState = MaterialSkin.MouseState.HOVER;
            this.botonsiguiente.Name = "botonsiguiente";
            this.botonsiguiente.Primary = true;
            this.botonsiguiente.Size = new System.Drawing.Size(186, 52);
            this.botonsiguiente.TabIndex = 33;
            this.botonsiguiente.Text = "Siguiente Inteligencia";
            this.botonsiguiente.UseVisualStyleBackColor = true;
            this.botonsiguiente.Click += new System.EventHandler(this.botonsiguiente_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(377, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "Seleccione la casilla si es el caso.";
            // 
            // r510
            // 
            this.r510.AutoSize = true;
            this.r510.BackColor = System.Drawing.Color.Transparent;
            this.r510.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r510.Location = new System.Drawing.Point(48, 561);
            this.r510.Name = "r510";
            this.r510.Size = new System.Drawing.Size(840, 24);
            this.r510.TabIndex = 30;
            this.r510.Text = "Acostumbro a producir sonidos ritmicos con golpecitos o a cantar melodias mientra" +
    "s estoy trabajando o estudiando.";
            this.r510.UseVisualStyleBackColor = false;
            // 
            // r59
            // 
            this.r59.AutoSize = true;
            this.r59.BackColor = System.Drawing.Color.Transparent;
            this.r59.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r59.Location = new System.Drawing.Point(48, 520);
            this.r59.Name = "r59";
            this.r59.Size = new System.Drawing.Size(833, 24);
            this.r59.TabIndex = 29;
            this.r59.Text = "Con sólo escuchar una selección musical con una o dos meses, ya soy capaz de repr" +
    "oducirla con bastante acierto.\r\n";
            this.r59.UseVisualStyleBackColor = false;
            // 
            // r58
            // 
            this.r58.AutoSize = true;
            this.r58.BackColor = System.Drawing.Color.Transparent;
            this.r58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r58.Location = new System.Drawing.Point(48, 473);
            this.r58.Name = "r58";
            this.r58.Size = new System.Drawing.Size(521, 24);
            this.r58.TabIndex = 28;
            this.r58.Text = "Conozco las melodias de numerosas canciones son piezas musicales.";
            this.r58.UseVisualStyleBackColor = false;
            // 
            // r57
            // 
            this.r57.AutoSize = true;
            this.r57.BackColor = System.Drawing.Color.Transparent;
            this.r57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r57.Location = new System.Drawing.Point(48, 424);
            this.r57.Name = "r57";
            this.r57.Size = new System.Drawing.Size(614, 24);
            this.r57.TabIndex = 27;
            this.r57.Text = "Puedo seguir fácilmente el ritmo del tema musical con un instrumento de percusión" +
    ".";
            this.r57.UseVisualStyleBackColor = false;
            // 
            // r56
            // 
            this.r56.AutoSize = true;
            this.r56.BackColor = System.Drawing.Color.Transparent;
            this.r56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r56.Location = new System.Drawing.Point(48, 379);
            this.r56.Name = "r56";
            this.r56.Size = new System.Drawing.Size(804, 24);
            this.r56.TabIndex = 26;
            this.r56.Text = "En ocaciones, me sorprendo cantando mentalmente la musica del anuncio de televisi" +
    "ón o alguna otra melodia.";
            this.r56.UseVisualStyleBackColor = false;
            // 
            // r55
            // 
            this.r55.AutoSize = true;
            this.r55.BackColor = System.Drawing.Color.Transparent;
            this.r55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r55.Location = new System.Drawing.Point(48, 330);
            this.r55.Name = "r55";
            this.r55.Size = new System.Drawing.Size(292, 24);
            this.r55.TabIndex = 25;
            this.r55.Text = "Sin la música, mi vida sería más triste.";
            this.r55.UseVisualStyleBackColor = false;
            // 
            // r54
            // 
            this.r54.AutoSize = true;
            this.r54.BackColor = System.Drawing.Color.Transparent;
            this.r54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r54.Location = new System.Drawing.Point(48, 289);
            this.r54.Name = "r54";
            this.r54.Size = new System.Drawing.Size(234, 24);
            this.r54.TabIndex = 24;
            this.r54.Text = "Tocó un instrumento musical.";
            this.r54.UseVisualStyleBackColor = false;
            // 
            // r53
            // 
            this.r53.AutoSize = true;
            this.r53.BackColor = System.Drawing.Color.Transparent;
            this.r53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r53.Location = new System.Drawing.Point(48, 242);
            this.r53.Name = "r53";
            this.r53.Size = new System.Drawing.Size(278, 24);
            this.r53.TabIndex = 23;
            this.r53.Text = "Siempre estoy escuchando música.";
            this.r53.UseVisualStyleBackColor = false;
            // 
            // r52
            // 
            this.r52.AutoSize = true;
            this.r52.BackColor = System.Drawing.Color.Transparent;
            this.r52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r52.Location = new System.Drawing.Point(48, 193);
            this.r52.Name = "r52";
            this.r52.Size = new System.Drawing.Size(379, 24);
            this.r52.TabIndex = 22;
            this.r52.Text = "Percibo cuando una nota musical esá desafinada.";
            this.r52.UseVisualStyleBackColor = false;
            // 
            // r51
            // 
            this.r51.AutoSize = true;
            this.r51.BackColor = System.Drawing.Color.Transparent;
            this.r51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r51.Location = new System.Drawing.Point(48, 148);
            this.r51.Name = "r51";
            this.r51.Size = new System.Drawing.Size(165, 24);
            this.r51.TabIndex = 21;
            this.r51.Text = "Una voz agradable.";
            this.r51.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(575, 91);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(395, 300);
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "Josias Dominguez Hernández";
            // 
            // Encuesta5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 678);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtinfo);
            this.Controls.Add(this.botonsiguiente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.r510);
            this.Controls.Add(this.r59);
            this.Controls.Add(this.r58);
            this.Controls.Add(this.r57);
            this.Controls.Add(this.r56);
            this.Controls.Add(this.r55);
            this.Controls.Add(this.r54);
            this.Controls.Add(this.r53);
            this.Controls.Add(this.r52);
            this.Controls.Add(this.r51);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Encuesta5";
            this.Text = "Inteligencia musical";
            this.Load += new System.EventHandler(this.Encuesta5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtinfo;
        private MaterialSkin.Controls.MaterialRaisedButton botonsiguiente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox r510;
        private System.Windows.Forms.CheckBox r59;
        private System.Windows.Forms.CheckBox r58;
        private System.Windows.Forms.CheckBox r57;
        private System.Windows.Forms.CheckBox r56;
        private System.Windows.Forms.CheckBox r55;
        private System.Windows.Forms.CheckBox r54;
        private System.Windows.Forms.CheckBox r53;
        private System.Windows.Forms.CheckBox r52;
        private System.Windows.Forms.CheckBox r51;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}