﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Encuesta5 : MaterialSkin.Controls.MaterialForm
    {
        int resultados5=0;
        public Encuesta5(int matricula,int resultados1, int resultados2, int resultados3, int resultados4)
        {
            InitializeComponent();
            this.matricula = matricula;
            this.resultados1 = resultados1;
            this.resultados2 = resultados2;
            this.resultados3 = resultados3;
            this.resultados4 = resultados4;
        }
        int matricula;
        int resultados1;
        int resultados2;
        int resultados3;
        int resultados4;

        private void Encuesta5_Load(object sender, EventArgs e)
        {

        }

        private void botonsiguiente_Click(object sender, EventArgs e)
        {
            if (r51.Checked == true)
            {
                resultados5 += 1;
            }
            if (r52.Checked == true)
            {
                resultados5 += 1;
            }
            if (r53.Checked == true)
            {
                resultados5 += 1;
            }
            if (r54.Checked == true)
            {
                resultados5 += 1;
            }
            if (r55.Checked == true)
            {
                resultados5 += 1;
            }
            if (r56.Checked == true)
            {
                resultados5 += 1;
            }
            if (r57.Checked == true)
            {
                resultados5 += 1;
            }
            if (r58.Checked == true)
            {
                resultados5 += 1;
            }
            if (r59.Checked == true)
            {
                resultados5 += 1;
            }
            if (r510.Checked == true)
            {
                resultados5 += 1;
            }
            if (r51.Checked == false && r52.Checked == false && r53.Checked == false && r54.Checked == false && r55.Checked == false && r56.Checked == false && r57.Checked == false && r58.Checked == false && r59.Checked == false && r510.Checked == false)
            {
                MessageBox.Show("Talvez no sea lo tuyo esta inteligencia, no?", "Información, antes de avanzar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            Seccion5 s5 = new Seccion5();
            s5.Matricula = matricula;
            s5.p1_s5 = r51.Checked;
            s5.p2_s5 = r52.Checked;
            s5.p3_s5 = r53.Checked;
            s5.p4_s5 = r54.Checked;
            s5.p5_s5 = r55.Checked;
            s5.p6_s5 = r56.Checked;
            s5.p7_s5 = r57.Checked;
            s5.p8_s5 = r58.Checked;
            s5.p9_s5 = r59.Checked;
            s5.p10_s5 = r510.Checked;


            int resultado = EncuestadoDAO.Seccion5(s5);
            if (resultado > 0)
            {
                MessageBox.Show("Perfecto 5/8!!", "Avance", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
            ResultadosTest resultadoss = new ResultadosTest(resultados1, resultados2, resultados3, resultados4, resultados5, 0, 0, 0,matricula);
            Encuesta6 encuesta6 = new Encuesta6(matricula,resultados1,resultados2,resultados3,resultados4,resultados5);
            encuesta6.Show();
            this.Hide();
        }
    }
}
