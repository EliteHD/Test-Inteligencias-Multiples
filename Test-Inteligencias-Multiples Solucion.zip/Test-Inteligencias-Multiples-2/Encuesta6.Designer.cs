﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Encuesta6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Encuesta6));
            this.txtinfo = new System.Windows.Forms.Label();
            this.botonsiguiente = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label3 = new System.Windows.Forms.Label();
            this.r610 = new System.Windows.Forms.CheckBox();
            this.r69 = new System.Windows.Forms.CheckBox();
            this.r68 = new System.Windows.Forms.CheckBox();
            this.r67 = new System.Windows.Forms.CheckBox();
            this.r66 = new System.Windows.Forms.CheckBox();
            this.r65 = new System.Windows.Forms.CheckBox();
            this.r64 = new System.Windows.Forms.CheckBox();
            this.r63 = new System.Windows.Forms.CheckBox();
            this.r62 = new System.Windows.Forms.CheckBox();
            this.r61 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtinfo
            // 
            this.txtinfo.AutoSize = true;
            this.txtinfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfo.Location = new System.Drawing.Point(766, 546);
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(0, 13);
            this.txtinfo.TabIndex = 34;
            // 
            // botonsiguiente
            // 
            this.botonsiguiente.Depth = 0;
            this.botonsiguiente.Location = new System.Drawing.Point(769, 575);
            this.botonsiguiente.MouseState = MaterialSkin.MouseState.HOVER;
            this.botonsiguiente.Name = "botonsiguiente";
            this.botonsiguiente.Primary = true;
            this.botonsiguiente.Size = new System.Drawing.Size(186, 52);
            this.botonsiguiente.TabIndex = 33;
            this.botonsiguiente.Text = "Siguiente Inteligencia";
            this.botonsiguiente.UseVisualStyleBackColor = true;
            this.botonsiguiente.Click += new System.EventHandler(this.botonsiguiente_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(375, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "Seleccione la casilla si es el caso.";
            // 
            // r610
            // 
            this.r610.AutoSize = true;
            this.r610.BackColor = System.Drawing.Color.Transparent;
            this.r610.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r610.Location = new System.Drawing.Point(46, 560);
            this.r610.Name = "r610";
            this.r610.Size = new System.Drawing.Size(488, 24);
            this.r610.TabIndex = 30;
            this.r610.Text = "Prefiero pasar una tarde en una fiesta animada que solo en casa.";
            this.r610.UseVisualStyleBackColor = false;
            // 
            // r69
            // 
            this.r69.AutoSize = true;
            this.r69.BackColor = System.Drawing.Color.Transparent;
            this.r69.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r69.Location = new System.Drawing.Point(46, 519);
            this.r69.Name = "r69";
            this.r69.Size = new System.Drawing.Size(792, 24);
            this.r69.TabIndex = 29;
            this.r69.Text = "Me gusta participar en actividades sociales relacionadas con mi trabajo, con la p" +
    "arroquia o con la comunidad.";
            this.r69.UseVisualStyleBackColor = false;
            this.r69.CheckedChanged += new System.EventHandler(this.r9_CheckedChanged);
            // 
            // r68
            // 
            this.r68.AutoSize = true;
            this.r68.BackColor = System.Drawing.Color.Transparent;
            this.r68.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r68.Location = new System.Drawing.Point(46, 472);
            this.r68.Name = "r68";
            this.r68.Size = new System.Drawing.Size(294, 24);
            this.r68.TabIndex = 28;
            this.r68.Text = "Me siento cómodo entre una multitud.";
            this.r68.UseVisualStyleBackColor = false;
            // 
            // r67
            // 
            this.r67.AutoSize = true;
            this.r67.BackColor = System.Drawing.Color.Transparent;
            this.r67.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r67.Location = new System.Drawing.Point(46, 423);
            this.r67.Name = "r67";
            this.r67.Size = new System.Drawing.Size(424, 24);
            this.r67.TabIndex = 27;
            this.r67.Text = "Me considero un lider (o los demás me dicen que lo soy).";
            this.r67.UseVisualStyleBackColor = false;
            // 
            // r66
            // 
            this.r66.AutoSize = true;
            this.r66.BackColor = System.Drawing.Color.Transparent;
            this.r66.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r66.Location = new System.Drawing.Point(46, 378);
            this.r66.Name = "r66";
            this.r66.Size = new System.Drawing.Size(701, 24);
            this.r66.TabIndex = 26;
            this.r66.Text = "Disfruto con el reto que supone enseñar a otra persona, o gurpos de personas, lo " +
    "que se hacer.";
            this.r66.UseVisualStyleBackColor = false;
            // 
            // r65
            // 
            this.r65.AutoSize = true;
            this.r65.BackColor = System.Drawing.Color.Transparent;
            this.r65.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r65.Location = new System.Drawing.Point(46, 329);
            this.r65.Name = "r65";
            this.r65.Size = new System.Drawing.Size(690, 24);
            this.r65.TabIndex = 25;
            this.r65.Text = "Me gustan más los juegos sociales (como Monopoly) que los juegos en solitario (Vi" +
    "deojuegos).";
            this.r65.UseVisualStyleBackColor = false;
            // 
            // r64
            // 
            this.r64.AutoSize = true;
            this.r64.BackColor = System.Drawing.Color.Transparent;
            this.r64.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r64.Location = new System.Drawing.Point(46, 288);
            this.r64.Name = "r64";
            this.r64.Size = new System.Drawing.Size(285, 24);
            this.r64.TabIndex = 24;
            this.r64.Text = "Tengo al menos tres amigos intimos.";
            this.r64.UseVisualStyleBackColor = false;
            // 
            // r63
            // 
            this.r63.AutoSize = true;
            this.r63.BackColor = System.Drawing.Color.Transparent;
            this.r63.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r63.Location = new System.Drawing.Point(46, 241);
            this.r63.Name = "r63";
            this.r63.Size = new System.Drawing.Size(830, 24);
            this.r63.TabIndex = 23;
            this.r63.Text = "Cuando tengo un problema, tiendo a buscar la ayuda de otra persona en lugar de in" +
    "tentar resolverlo por mi mismo.";
            this.r63.UseVisualStyleBackColor = false;
            // 
            // r62
            // 
            this.r62.AutoSize = true;
            this.r62.BackColor = System.Drawing.Color.Transparent;
            this.r62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r62.Location = new System.Drawing.Point(46, 192);
            this.r62.Name = "r62";
            this.r62.Size = new System.Drawing.Size(726, 24);
            this.r62.TabIndex = 22;
            this.r62.Text = "Prefiero los deportes de equipo (futbol o baloncesto) a los deportes solitarios (" +
    "natación o el jogging)";
            this.r62.UseVisualStyleBackColor = false;
            // 
            // r61
            // 
            this.r61.AutoSize = true;
            this.r61.BackColor = System.Drawing.Color.Transparent;
            this.r61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r61.Location = new System.Drawing.Point(46, 147);
            this.r61.Name = "r61";
            this.r61.Size = new System.Drawing.Size(724, 24);
            this.r61.TabIndex = 21;
            this.r61.Text = "Soy del tipo de persona a las que los demas pide opinion y consejos en el trabajo" +
    " y en el vecindario.";
            this.r61.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(716, 378);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(209, 149);
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "Josias Dominguez Hernández";
            // 
            // Encuesta6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 639);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtinfo);
            this.Controls.Add(this.botonsiguiente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.r610);
            this.Controls.Add(this.r69);
            this.Controls.Add(this.r68);
            this.Controls.Add(this.r67);
            this.Controls.Add(this.r66);
            this.Controls.Add(this.r65);
            this.Controls.Add(this.r64);
            this.Controls.Add(this.r63);
            this.Controls.Add(this.r62);
            this.Controls.Add(this.r61);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Encuesta6";
            this.Text = "Inteligencia interpersonal";
            this.Load += new System.EventHandler(this.Encuesta6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtinfo;
        private MaterialSkin.Controls.MaterialRaisedButton botonsiguiente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox r610;
        private System.Windows.Forms.CheckBox r69;
        private System.Windows.Forms.CheckBox r68;
        private System.Windows.Forms.CheckBox r67;
        private System.Windows.Forms.CheckBox r66;
        private System.Windows.Forms.CheckBox r65;
        private System.Windows.Forms.CheckBox r64;
        private System.Windows.Forms.CheckBox r63;
        private System.Windows.Forms.CheckBox r62;
        private System.Windows.Forms.CheckBox r61;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}