﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Encuesta6 : MaterialSkin.Controls.MaterialForm
    {
        int resultados6=0;
        public Encuesta6(int matricula, int resultados1, int resultados2, int resultados3, int resultados4,int resultados5)
        {
            InitializeComponent();
            this.matricula = matricula;
            this.resultados1 = resultados1;
            this.resultados2 = resultados2;
            this.resultados3 = resultados3;
            this.resultados4 = resultados4;
            this.resultados5 = resultados5;
        }
        int matricula;
        int resultados1, resultados2, resultados3, resultados4, resultados5;

        private void Encuesta6_Load(object sender, EventArgs e)
        {

        }

        private void botonsiguiente_Click(object sender, EventArgs e)
        {
            if (r61.Checked == true)
            {
                resultados6 += 1;
            }
            if (r62.Checked == true)
            {
                resultados6 += 1;
            }
            if (r63.Checked == true)
            {
                resultados6 += 1;
            }
            if (r64.Checked == true)
            {
                resultados6 += 1;
            }
            if (r65.Checked == true)
            {
                resultados6 += 1;
            }
            if (r66.Checked == true)
            {
                resultados6 += 1;
            }
            if (r67.Checked == true)
            {
                resultados6 += 1;
            }
            if (r68.Checked == true)
            {
                resultados6 += 1;
            }
            if (r69.Checked == true)
            {
                resultados6 += 1;
            }
            if (r610.Checked == true)
            {
                resultados6 += 1;
            }
            if (r61.Checked == false && r62.Checked == false && r63.Checked == false && r64.Checked == false && r65.Checked == false && r66.Checked == false && r67.Checked == false && r68.Checked == false && r69.Checked == false && r610.Checked == false)
            {
                MessageBox.Show("Talvez no sea lo tuyo esta inteligencia, no?", "Información, antes de avanzar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            Seccion6 s6 = new Seccion6();
            s6.Matricula = matricula;
            s6.p1_s6 = r61.Checked;
            s6.p2_s6 = r62.Checked;
            s6.p3_s6 = r63.Checked;
            s6.p4_s6 = r64.Checked;
            s6.p5_s6 = r65.Checked;
            s6.p6_s6 = r66.Checked;
            s6.p7_s6 = r67.Checked;
            s6.p8_s6 = r68.Checked;
            s6.p9_s6 = r69.Checked;
            s6.p10_s6 = r610.Checked;


            int resultado = EncuestadoDAO.Seccion6(s6);
            if (resultado > 0)
            {
                MessageBox.Show("Perfecto 6/8!!", "Avance", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
            ResultadosTest resultadoss = new ResultadosTest(resultados1, resultados2, resultados3, resultados4, resultados5, resultados6, 0, 0,matricula);

            Encuesta7 encuesta7 = new Encuesta7(matricula, resultados1, resultados2, resultados3, resultados4, resultados5, resultados6);
            encuesta7.Show();
            this.Hide();
        }

        private void r9_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
