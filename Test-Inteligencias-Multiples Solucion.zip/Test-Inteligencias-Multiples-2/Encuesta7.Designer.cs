﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Encuesta7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Encuesta7));
            this.txtinfo = new System.Windows.Forms.Label();
            this.botonsiguiente = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label3 = new System.Windows.Forms.Label();
            this.r710 = new System.Windows.Forms.CheckBox();
            this.r79 = new System.Windows.Forms.CheckBox();
            this.r78 = new System.Windows.Forms.CheckBox();
            this.r77 = new System.Windows.Forms.CheckBox();
            this.r76 = new System.Windows.Forms.CheckBox();
            this.r75 = new System.Windows.Forms.CheckBox();
            this.r74 = new System.Windows.Forms.CheckBox();
            this.r73 = new System.Windows.Forms.CheckBox();
            this.r72 = new System.Windows.Forms.CheckBox();
            this.r71 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtinfo
            // 
            this.txtinfo.AutoSize = true;
            this.txtinfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfo.Location = new System.Drawing.Point(769, 541);
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(0, 13);
            this.txtinfo.TabIndex = 34;
            // 
            // botonsiguiente
            // 
            this.botonsiguiente.Depth = 0;
            this.botonsiguiente.Location = new System.Drawing.Point(785, 609);
            this.botonsiguiente.MouseState = MaterialSkin.MouseState.HOVER;
            this.botonsiguiente.Name = "botonsiguiente";
            this.botonsiguiente.Primary = true;
            this.botonsiguiente.Size = new System.Drawing.Size(186, 52);
            this.botonsiguiente.TabIndex = 33;
            this.botonsiguiente.Text = "Siguiente Inteligencia";
            this.botonsiguiente.UseVisualStyleBackColor = true;
            this.botonsiguiente.Click += new System.EventHandler(this.botonsiguiente_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(378, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "Seleccione la casilla si es el caso.";
            // 
            // r710
            // 
            this.r710.AutoSize = true;
            this.r710.BackColor = System.Drawing.Color.Transparent;
            this.r710.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r710.Location = new System.Drawing.Point(49, 555);
            this.r710.Name = "r710";
            this.r710.Size = new System.Drawing.Size(818, 24);
            this.r710.TabIndex = 30;
            this.r710.Text = "Soy trabajador autónomo o he pensado muy seriamente en la posibilidad de poner en" +
    " marcha mi propio negocio.";
            this.r710.UseVisualStyleBackColor = false;
            // 
            // r79
            // 
            this.r79.AutoSize = true;
            this.r79.BackColor = System.Drawing.Color.Transparent;
            this.r79.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r79.Location = new System.Drawing.Point(49, 514);
            this.r79.Name = "r79";
            this.r79.Size = new System.Drawing.Size(686, 24);
            this.r79.TabIndex = 29;
            this.r79.Text = "Escribo un diario personal en el que recojo los pensamientos relacionados con mi " +
    "vida interior.";
            this.r79.UseVisualStyleBackColor = false;
            // 
            // r78
            // 
            this.r78.AutoSize = true;
            this.r78.BackColor = System.Drawing.Color.Transparent;
            this.r78.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r78.Location = new System.Drawing.Point(49, 467);
            this.r78.Name = "r78";
            this.r78.Size = new System.Drawing.Size(555, 24);
            this.r78.TabIndex = 28;
            this.r78.Text = "Me considero una persona con mucha fuerza de voluntad o independiente.";
            this.r78.UseVisualStyleBackColor = false;
            // 
            // r77
            // 
            this.r77.AutoSize = true;
            this.r77.BackColor = System.Drawing.Color.Transparent;
            this.r77.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r77.Location = new System.Drawing.Point(49, 418);
            this.r77.Name = "r77";
            this.r77.Size = new System.Drawing.Size(838, 24);
            this.r77.TabIndex = 27;
            this.r77.Text = "Preferiría pasar un fin de semana solo en una cabaña, en el bosque, que en un lug" +
    "ar turístico de lujo lleno de gente.";
            this.r77.UseVisualStyleBackColor = false;
            // 
            // r76
            // 
            this.r76.AutoSize = true;
            this.r76.BackColor = System.Drawing.Color.Transparent;
            this.r76.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r76.Location = new System.Drawing.Point(49, 373);
            this.r76.Name = "r76";
            this.r76.Size = new System.Drawing.Size(816, 24);
            this.r76.TabIndex = 26;
            this.r76.Text = "Mantengo una visión realista de mis puntos fuertes y débiles (confirmados mediant" +
    "e feedback de otras fuentes).";
            this.r76.UseVisualStyleBackColor = false;
            // 
            // r75
            // 
            this.r75.AutoSize = true;
            this.r75.BackColor = System.Drawing.Color.Transparent;
            this.r75.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r75.Location = new System.Drawing.Point(49, 324);
            this.r75.Name = "r75";
            this.r75.Size = new System.Drawing.Size(594, 24);
            this.r75.TabIndex = 25;
            this.r75.Text = "Tengo algunos objetivos vitales importantes en los que pienso de forma habitual.";
            this.r75.UseVisualStyleBackColor = false;
            // 
            // r74
            // 
            this.r74.AutoSize = true;
            this.r74.BackColor = System.Drawing.Color.Transparent;
            this.r74.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r74.Location = new System.Drawing.Point(49, 283);
            this.r74.Name = "r74";
            this.r74.Size = new System.Drawing.Size(471, 24);
            this.r74.TabIndex = 24;
            this.r74.Text = "Tengo una afición especial o una actividad que guardo para mí.";
            this.r74.UseVisualStyleBackColor = false;
            // 
            // r73
            // 
            this.r73.AutoSize = true;
            this.r73.BackColor = System.Drawing.Color.Transparent;
            this.r73.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r73.Location = new System.Drawing.Point(49, 236);
            this.r73.Name = "r73";
            this.r73.Size = new System.Drawing.Size(439, 24);
            this.r73.TabIndex = 23;
            this.r73.Text = "Soy capaz de afrontar los contratiempos con fuerza moral.";
            this.r73.UseVisualStyleBackColor = false;
            // 
            // r72
            // 
            this.r72.AutoSize = true;
            this.r72.BackColor = System.Drawing.Color.Transparent;
            this.r72.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r72.Location = new System.Drawing.Point(49, 187);
            this.r72.Name = "r72";
            this.r72.Size = new System.Drawing.Size(834, 24);
            this.r72.TabIndex = 22;
            this.r72.Text = "He asistido a sesiones de asesoramiento o a seminarios de crecimiento personal pa" +
    "ra aprender a conocerme más.";
            this.r72.UseVisualStyleBackColor = false;
            // 
            // r71
            // 
            this.r71.AutoSize = true;
            this.r71.BackColor = System.Drawing.Color.Transparent;
            this.r71.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r71.Location = new System.Drawing.Point(49, 142);
            this.r71.Name = "r71";
            this.r71.Size = new System.Drawing.Size(699, 24);
            this.r71.TabIndex = 21;
            this.r71.Text = " Habitualmente dedico tiempo a meditar, reflexionar o pensar cuestiones important" +
    "es de la vida.";
            this.r71.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(665, 187);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(289, 213);
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "Josias Dominguez Hernández";
            // 
            // Encuesta7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 683);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtinfo);
            this.Controls.Add(this.botonsiguiente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.r710);
            this.Controls.Add(this.r79);
            this.Controls.Add(this.r78);
            this.Controls.Add(this.r77);
            this.Controls.Add(this.r76);
            this.Controls.Add(this.r75);
            this.Controls.Add(this.r74);
            this.Controls.Add(this.r73);
            this.Controls.Add(this.r72);
            this.Controls.Add(this.r71);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Encuesta7";
            this.Text = "Inteligencia intrapersonal";
            this.Load += new System.EventHandler(this.Encuesta7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtinfo;
        private MaterialSkin.Controls.MaterialRaisedButton botonsiguiente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox r710;
        private System.Windows.Forms.CheckBox r79;
        private System.Windows.Forms.CheckBox r78;
        private System.Windows.Forms.CheckBox r77;
        private System.Windows.Forms.CheckBox r76;
        private System.Windows.Forms.CheckBox r75;
        private System.Windows.Forms.CheckBox r74;
        private System.Windows.Forms.CheckBox r73;
        private System.Windows.Forms.CheckBox r72;
        private System.Windows.Forms.CheckBox r71;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}