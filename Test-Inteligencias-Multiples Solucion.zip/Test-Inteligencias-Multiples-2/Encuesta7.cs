﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Encuesta7 : MaterialSkin.Controls.MaterialForm
    {
        int resultados7=0;
        public Encuesta7(int matricula, int resultados1, int resultados2, int resultados3, int resultados4, int resultados5,int resultados6)
        {
            InitializeComponent();
            this.matricula = matricula;
            this.resultados1 = resultados1;
            this.resultados2 = resultados2;
            this.resultados3 = resultados3;
            this.resultados4 = resultados4;
            this.resultados5 = resultados5;
            this.resultados6 = resultados6;
        }
        int matricula;
        int resultados1, resultados2, resultados3, resultados4, resultados5,resultados6;

        private void Encuesta7_Load(object sender, EventArgs e)
        {

        }

        private void botonsiguiente_Click(object sender, EventArgs e)
        {
            if (r71.Checked == true)
            {
                resultados7 += 1;
            }
            if (r72.Checked == true)
            {
                resultados7 += 1;
            }
            if (r73.Checked == true)
            {
                resultados7 += 1;
            }
            if (r74.Checked == true)
            {
                resultados7 += 1;
            }
            if (r75.Checked == true)
            {
                resultados7 += 1;
            }
            if (r76.Checked == true)
            {
                resultados7 += 1;
            }
            if (r77.Checked == true)
            {
                resultados7 += 1;
            }
            if (r78.Checked == true)
            {
                resultados7 += 1;
            }
            if (r79.Checked == true)
            {
                resultados7 += 1;
            }
            if (r710.Checked == true)
            {
                resultados7 += 1;
            }
            if (r71.Checked == false && r72.Checked == false && r73.Checked == false && r74.Checked == false && r75.Checked == false && r76.Checked == false && r77.Checked == false && r78.Checked == false && r79.Checked == false && r710.Checked == false)
            {
                MessageBox.Show("Talvez no sea lo tuyo esta inteligencia, no?", "Información, antes de avanzar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            Seccion7 s7 = new Seccion7();
            s7.Matricula = matricula;
            s7.p1_s7 = r71.Checked;
            s7.p2_s7 = r72.Checked;
            s7.p3_s7 = r73.Checked;
            s7.p4_s7 = r74.Checked;
            s7.p5_s7 = r75.Checked;
            s7.p6_s7 = r76.Checked;
            s7.p7_s7 = r77.Checked;
            s7.p8_s7 = r78.Checked;
            s7.p9_s7 = r79.Checked;
            s7.p10_s7 = r710.Checked;


            int resultado = EncuestadoDAO.Seccion7(s7);
            if (resultado > 0)
            {
                MessageBox.Show("Perfecto 7/8!!", "Avance", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
            ResultadosTest resultadoss = new ResultadosTest(resultados1, resultados2, resultados3, resultados4, resultados5, resultados6, resultados7, 0,matricula);

            Encuesta8 encuesta8 = new Encuesta8(matricula, resultados1, resultados2, resultados3, resultados4, resultados5, resultados6,resultados7);
            encuesta8.Show();
            this.Hide();
        }
    }
}
