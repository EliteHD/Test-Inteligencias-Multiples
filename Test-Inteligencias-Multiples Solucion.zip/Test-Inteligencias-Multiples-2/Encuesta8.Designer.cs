﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Encuesta8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Encuesta8));
            this.txtinfo = new System.Windows.Forms.Label();
            this.botonsiguiente = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label3 = new System.Windows.Forms.Label();
            this.r810 = new System.Windows.Forms.CheckBox();
            this.r89 = new System.Windows.Forms.CheckBox();
            this.r88 = new System.Windows.Forms.CheckBox();
            this.r87 = new System.Windows.Forms.CheckBox();
            this.r86 = new System.Windows.Forms.CheckBox();
            this.r85 = new System.Windows.Forms.CheckBox();
            this.r84 = new System.Windows.Forms.CheckBox();
            this.r83 = new System.Windows.Forms.CheckBox();
            this.r82 = new System.Windows.Forms.CheckBox();
            this.r81 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtinfo
            // 
            this.txtinfo.AutoSize = true;
            this.txtinfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfo.Location = new System.Drawing.Point(768, 534);
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(0, 13);
            this.txtinfo.TabIndex = 34;
            // 
            // botonsiguiente
            // 
            this.botonsiguiente.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.botonsiguiente.Depth = 0;
            this.botonsiguiente.Location = new System.Drawing.Point(562, 590);
            this.botonsiguiente.MouseState = MaterialSkin.MouseState.HOVER;
            this.botonsiguiente.Name = "botonsiguiente";
            this.botonsiguiente.Primary = true;
            this.botonsiguiente.Size = new System.Drawing.Size(395, 64);
            this.botonsiguiente.TabIndex = 33;
            this.botonsiguiente.Text = "Consultar Resultados";
            this.botonsiguiente.UseVisualStyleBackColor = false;
            this.botonsiguiente.Click += new System.EventHandler(this.botonsiguiente_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(377, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "Seleccione la casilla si es el caso.";
            // 
            // r810
            // 
            this.r810.AutoSize = true;
            this.r810.BackColor = System.Drawing.Color.Transparent;
            this.r810.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r810.Location = new System.Drawing.Point(48, 548);
            this.r810.Name = "r810";
            this.r810.Size = new System.Drawing.Size(290, 24);
            this.r810.TabIndex = 30;
            this.r810.Text = "Tengo un jardín y disfrutó cuidándolo.";
            this.r810.UseVisualStyleBackColor = false;
            // 
            // r89
            // 
            this.r89.AutoSize = true;
            this.r89.BackColor = System.Drawing.Color.Transparent;
            this.r89.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r89.Location = new System.Drawing.Point(48, 507);
            this.r89.Name = "r89";
            this.r89.Size = new System.Drawing.Size(674, 24);
            this.r89.TabIndex = 29;
            this.r89.Text = "Me encanta visitar zoológicos, acuarios y demás lugares donde se estudia el mundo" +
    " natural.";
            this.r89.UseVisualStyleBackColor = false;
            // 
            // r88
            // 
            this.r88.AutoSize = true;
            this.r88.BackColor = System.Drawing.Color.Transparent;
            this.r88.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r88.Location = new System.Drawing.Point(48, 460);
            this.r88.Name = "r88";
            this.r88.Size = new System.Drawing.Size(831, 24);
            this.r88.TabIndex = 28;
            this.r88.Text = "Cuando tengo vacaciones, prefiero los entornos naturales (parques, senderismo) a " +
    "los hoteles y destinos urbanos.";
            this.r88.UseVisualStyleBackColor = false;
            // 
            // r87
            // 
            this.r87.AutoSize = true;
            this.r87.BackColor = System.Drawing.Color.Transparent;
            this.r87.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r87.Location = new System.Drawing.Point(48, 411);
            this.r87.Name = "r87";
            this.r87.Size = new System.Drawing.Size(809, 24);
            this.r87.TabIndex = 27;
            this.r87.Text = "Me gusta leer libros o revistas, o ver programas de televisión o películas, en lo" +
    "s que la naturaleza esté presente.";
            this.r87.UseVisualStyleBackColor = false;
            // 
            // r86
            // 
            this.r86.AutoSize = true;
            this.r86.BackColor = System.Drawing.Color.Transparent;
            this.r86.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r86.Location = new System.Drawing.Point(48, 366);
            this.r86.Name = "r86";
            this.r86.Size = new System.Drawing.Size(846, 24);
            this.r86.TabIndex = 26;
            this.r86.Text = "Se me da bien describir diferencias entre distintos tipos de árboles, perros, páj" +
    "aros u otras especies de flora o fauna.";
            this.r86.UseVisualStyleBackColor = false;
            // 
            // r85
            // 
            this.r85.AutoSize = true;
            this.r85.BackColor = System.Drawing.Color.Transparent;
            this.r85.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r85.Location = new System.Drawing.Point(48, 317);
            this.r85.Name = "r85";
            this.r85.Size = new System.Drawing.Size(635, 24);
            this.r85.TabIndex = 25;
            this.r85.Text = "He asistido a cursos relacionados con la naturaleza (por ejemplo, botánica o zool" +
    "ogía).";
            this.r85.UseVisualStyleBackColor = false;
            // 
            // r84
            // 
            this.r84.AutoSize = true;
            this.r84.BackColor = System.Drawing.Color.Transparent;
            this.r84.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r84.Location = new System.Drawing.Point(48, 276);
            this.r84.Name = "r84";
            this.r84.Size = new System.Drawing.Size(742, 24);
            this.r84.TabIndex = 24;
            this.r84.Text = "Tengo una afición relacionada de algún modo con la naturaleza (por ejemplo, la ob" +
    "servación de aves).";
            this.r84.UseVisualStyleBackColor = false;
            // 
            // r83
            // 
            this.r83.AutoSize = true;
            this.r83.BackColor = System.Drawing.Color.Transparent;
            this.r83.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r83.Location = new System.Drawing.Point(48, 229);
            this.r83.Name = "r83";
            this.r83.Size = new System.Drawing.Size(284, 24);
            this.r83.TabIndex = 23;
            this.r83.Text = "Me encanta tener animales en casa.";
            this.r83.UseVisualStyleBackColor = false;
            // 
            // r82
            // 
            this.r82.AutoSize = true;
            this.r82.BackColor = System.Drawing.Color.Transparent;
            this.r82.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r82.Location = new System.Drawing.Point(48, 180);
            this.r82.Name = "r82";
            this.r82.Size = new System.Drawing.Size(705, 24);
            this.r82.TabIndex = 22;
            this.r82.Text = "Pertenezco a una asociación de voluntarios relacionada con la conservación del Me" +
    "dioambiente.";
            this.r82.UseVisualStyleBackColor = false;
            // 
            // r81
            // 
            this.r81.AutoSize = true;
            this.r81.BackColor = System.Drawing.Color.Transparent;
            this.r81.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r81.Location = new System.Drawing.Point(48, 135);
            this.r81.Name = "r81";
            this.r81.Size = new System.Drawing.Size(613, 24);
            this.r81.TabIndex = 21;
            this.r81.Text = "Me gusta ir de excursión, el senderismo o simplemente pasear en plena naturaleza." +
    "";
            this.r81.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(689, 94);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(303, 272);
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "Josias Dominguez Hernández";
            // 
            // Encuesta8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 687);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtinfo);
            this.Controls.Add(this.botonsiguiente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.r810);
            this.Controls.Add(this.r89);
            this.Controls.Add(this.r88);
            this.Controls.Add(this.r87);
            this.Controls.Add(this.r86);
            this.Controls.Add(this.r85);
            this.Controls.Add(this.r84);
            this.Controls.Add(this.r83);
            this.Controls.Add(this.r82);
            this.Controls.Add(this.r81);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Encuesta8";
            this.Text = "Inteligencia naturalista";
            this.Load += new System.EventHandler(this.Encuesta8_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtinfo;
        private MaterialSkin.Controls.MaterialRaisedButton botonsiguiente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox r810;
        private System.Windows.Forms.CheckBox r89;
        private System.Windows.Forms.CheckBox r88;
        private System.Windows.Forms.CheckBox r87;
        private System.Windows.Forms.CheckBox r86;
        private System.Windows.Forms.CheckBox r85;
        private System.Windows.Forms.CheckBox r84;
        private System.Windows.Forms.CheckBox r83;
        private System.Windows.Forms.CheckBox r82;
        private System.Windows.Forms.CheckBox r81;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}