﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Encuesta8 : MaterialSkin.Controls.MaterialForm
    {
        int resultados8=0;
        public Encuesta8(int matricula, int resultados1, int resultados2, int resultados3, int resultados4, int resultados5,int resultados6, int resultados7)
        {
            InitializeComponent();
            this.matricula = matricula;
            this.resultados1 = resultados1;
            this.resultados2 = resultados2;
            this.resultados3 = resultados3;
            this.resultados4 = resultados4;
            this.resultados5 = resultados5;
            this.resultados6 = resultados6;
            this.resultados7 = resultados7;
        }
        int matricula;
        int resultados1, resultados2, resultados3, resultados4, resultados5,resultados6,resultados7;
        private void Encuesta8_Load(object sender, EventArgs e)
        {

        }

        private void botonsiguiente_Click(object sender, EventArgs e)
        {
            if (r81.Checked == true)
            {
                resultados8 += 1;
            }
            if (r82.Checked == true)
            {
                resultados8 += 1;
            }
            if (r83.Checked == true)
            {
                resultados8 += 1;
            }
            if (r84.Checked == true)
            {
                resultados8 += 1;
            }
            if (r85.Checked == true)
            {
                resultados8 += 1;
            }
            if (r86.Checked == true)
            {
                resultados8 += 1;
            }
            if (r87.Checked == true)
            {
                resultados8 += 1;
            }
            if (r88.Checked == true)
            {
                resultados8 += 1;
            }
            if (r89.Checked == true)
            {
                resultados8 += 1;
            }
            if (r810.Checked == true)
            {
                resultados8 += 1;
            }
            if (r81.Checked == false && r82.Checked == false && r83.Checked == false && r84.Checked == false && r85.Checked == false && r86.Checked == false && r87.Checked == false && r88.Checked == false && r89.Checked == false && r810.Checked == false)
            {
                MessageBox.Show("Talvez no sea lo tuyo esta inteligencia, no?", "Información, antes de avanzar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            Seccion8 s8 = new Seccion8();
            s8.Matricula = matricula;
            s8.p1_s8 = r81.Checked;
            s8.p2_s8 = r82.Checked;
            s8.p3_s8 = r83.Checked;
            s8.p4_s8 = r84.Checked;
            s8.p5_s8 = r85.Checked;
            s8.p6_s8 = r86.Checked;
            s8.p7_s8 = r87.Checked;
            s8.p8_s8 = r88.Checked;
            s8.p9_s8 = r89.Checked;
            s8.p10_s8 = r810.Checked;


            int resultado = EncuestadoDAO.Seccion8(s8);
            if (resultado > 0)
            {
                MessageBox.Show("Perfecto 8/8!!   Gracias por participar en este pequeño test", "Test Completado! ", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
            ResultadosTest resultadoss = new ResultadosTest(resultados1, resultados2, resultados3, resultados4, resultados5, resultados6, resultados7, resultados8,matricula);
            resultadoss.Show();
            this.Hide();
        }
    }
}
