﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class Encuestado
    {
        public int Matricula { get; set; }
        public string Nombre { get; set; }
        public string Fechaacimiento { get; set; }
        public string Correo { get; set; }
        public long Celular { get; set; }
        public string FechaAplicacion { get; set; }
        public string Hora { get; set; }

        public Encuestado() { }
        public Encuestado(int Matricula, string Nombre, string Fechaacimiento, string Correo, long Celular, string FechaAplicacion, string Hora)
        {
            this.Matricula = Matricula;
            this.Nombre = Nombre;
            this.Fechaacimiento = Fechaacimiento;
            this.Correo = Correo;
            this.Celular = Celular;
            this.FechaAplicacion = FechaAplicacion;
            this.Hora = Hora;
        }
    }
}
