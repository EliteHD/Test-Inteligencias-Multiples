﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class EncuestadoDAO
    {
        public static int Agregar(Encuestado ENC)
        {
            int retorno = 0;
            using (NpgsqlConnection conectar = bdCon.ObtenerConexion())
            {
                NpgsqlCommand comando = new NpgsqlCommand(String.Format("Insert into testexamen (matricula,nombre,nacimiento,correo,celular,faplicacion,haplicacion) values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}')",
                    ENC.Matricula,ENC.Nombre,ENC.Fechaacimiento,ENC.Correo,ENC.Celular,ENC.FechaAplicacion,ENC.Hora), conectar);
                retorno = comando.ExecuteNonQuery();

            }
            return retorno;
        }
        public static int Seccion1(Seccion1 S1)
        {
            

            int retorno = 0;
            NpgsqlCommand comando = new NpgsqlCommand(string.Format("Update testexamen set p1_s1='{0}', p2_s1='{1}', p3_s1='{2}', p4_s1='{3}', p5_s1='{4}', p6_s1='{5}', p7_s1='{6}', p8_s1='{7}', p9_s1='{8}', p10_s1='{9}' Where matricula='{10}'",
             S1.p1_s1, S1.p2_s1, S1.p3_s1, S1.p4_s1, S1.p5_s1, S1.p6_s1, S1.p7_s1, S1.p8_s1, S1.p9_s1, S1.p10_s1,S1.Matricula), bdCon.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
        public static int Seccion2(Seccion2 S2)
        {


            int retorno = 0;
            NpgsqlCommand comando = new NpgsqlCommand(string.Format("Update testexamen set p1_s2='{0}', p2_s2='{1}', p3_s2='{2}', p4_s2='{3}', p5_s2='{4}', p6_s2='{5}', p7_s2='{6}', p8_s2='{7}', p9_s2='{8}', p10_s2='{9}' Where matricula='{10}'",
              S2.p1_s2, S2.p2_s2, S2.p3_s2, S2.p4_s2, S2.p5_s2, S2.p6_s2, S2.p7_s2, S2.p8_s2, S2.p9_s2, S2.p10_s2, S2.Matricula), bdCon.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
        public static int Seccion3(Seccion3 S3)
        {


            int retorno = 0;
            NpgsqlCommand comando = new NpgsqlCommand(string.Format("Update testexamen set p1_s3='{0}', p2_s3='{1}', p3_s3='{2}', p4_s3='{3}', p5_s3='{4}', p6_s3='{5}', p7_s3='{6}', p8_s3='{7}', p9_s3='{8}', p10_s3='{9}' Where matricula='{10}'",
             S3.p1_s3, S3.p2_s3, S3.p3_s3, S3.p4_s3, S3.p5_s3, S3.p6_s3, S3.p7_s3, S3.p8_s3, S3.p9_s3, S3.p10_s3, S3.Matricula), bdCon.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
        public static int Seccion4(Seccion4 S4)
        {


            int retorno = 0;
            NpgsqlCommand comando = new NpgsqlCommand(string.Format("Update testexamen set p1_s4='{0}', p2_s4='{1}', p3_s4='{2}', p4_s4='{3}', p5_s4='{4}', p6_s4='{5}', p7_s4='{6}', p8_s4='{7}', p9_s4='{8}', p10_s4='{9}' Where matricula='{10}'",
             S4.p1_s4, S4.p2_s4, S4.p3_s4, S4.p4_s4, S4.p5_s4, S4.p6_s4, S4.p7_s4, S4.p8_s4, S4.p9_s4, S4.p10_s4, S4.Matricula), bdCon.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
        public static int Seccion5(Seccion5 S5)
        {


            int retorno = 0;
            NpgsqlCommand comando = new NpgsqlCommand(string.Format("Update testexamen set p1_s5='{0}', p2_s5='{1}', p3_s5='{2}', p4_s5='{3}', p5_s5='{4}', p6_s5='{5}', p7_s5='{6}', p8_s5='{7}', p9_s5='{8}', p10_s5='{9}' Where matricula='{10}'",
             S5.p1_s5, S5.p2_s5, S5.p3_s5, S5.p4_s5, S5.p5_s5, S5.p6_s5, S5.p7_s5, S5.p8_s5, S5.p8_s5, S5.p10_s5, S5.Matricula), bdCon.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
        public static int Seccion6(Seccion6 S6)
        {


            int retorno = 0;
            NpgsqlCommand comando = new NpgsqlCommand(string.Format("Update testexamen set p1_s6='{0}', p2_s6='{1}', p3_s6='{2}', p4_s6='{3}', p5_s6='{4}', p6_s6='{5}', p7_s6='{6}', p8_s6='{7}', p9_s6='{8}', p10_s6='{9}' Where matricula='{10}'",
             S6.p1_s6, S6.p2_s6, S6.p3_s6, S6.p4_s6, S6.p5_s6, S6.p6_s6, S6.p7_s6, S6.p8_s6, S6.p9_s6, S6.p10_s6, S6.Matricula), bdCon.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
        public static int Seccion7(Seccion7 S7)
        {


            int retorno = 0;
            NpgsqlCommand comando = new NpgsqlCommand(string.Format("Update testexamen set p1_s7='{0}', p2_s7='{1}', p3_s7='{2}', p4_s7='{3}', p5_s7='{4}', p6_s7='{5}', p7_s7='{6}', p8_s7='{7}', p9_s7='{8}', p10_s7='{9}' Where matricula='{10}'",
             S7.p1_s7, S7.p2_s7, S7.p3_s7, S7.p4_s7, S7.p5_s7, S7.p6_s7, S7.p7_s7, S7.p8_s7, S7.p9_s7, S7.p10_s7, S7.Matricula), bdCon.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
        public static int Seccion8(Seccion8 S8)
        {


            int retorno = 0;
            NpgsqlCommand comando = new NpgsqlCommand(string.Format("Update testexamen set p1_s8='{0}', p2_s8='{1}', p3_s8='{2}', p4_s8='{3}', p5_s8='{4}', p6_s8='{5}', p7_s8='{6}', p8_s8='{7}', p9_s8='{8}', p10_s8='{9}' Where matricula='{10}'",
             S8.p1_s8, S8.p2_s8, S8.p3_s8, S8.p4_s8, S8.p5_s8, S8.p6_s8, S8.p7_s8, S8.p8_s8, S8.p9_s8, S8.p10_s8, S8.Matricula), bdCon.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
        public static int Resultadost(Resultados RR)
        {


            int retorno = 0;
            NpgsqlCommand comando = new NpgsqlCommand(string.Format("Update testexamen set resultado='{0}' Where matricula='{1}'",
             RR.Resultado, RR.Matricula), bdCon.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }

        
    }
}
