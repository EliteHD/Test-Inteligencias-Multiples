﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Modifica1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nombreLabel;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label9;
            System.Windows.Forms.Label label10;
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dataSet1 = new Test_Inteligencias_Multiples_2.DataSet1();
            this.testexamenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testexamenTableAdapter = new Test_Inteligencias_Multiples_2.DataSet1TableAdapters.testexamenTableAdapter();
            this.tableAdapterManager = new Test_Inteligencias_Multiples_2.DataSet1TableAdapters.TableAdapterManager();
            this.testexamenBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.datos = new Test_Inteligencias_Multiples_2.datos();
            this.testexamenTableAdapter1 = new Test_Inteligencias_Multiples_2.datosTableAdapters.testexamenTableAdapter();
            this.tableAdapterManager1 = new Test_Inteligencias_Multiples_2.datosTableAdapters.TableAdapterManager();
            this.nombreTextBox = new System.Windows.Forms.TextBox();
            this.matriculaTextBox = new System.Windows.Forms.TextBox();
            this.faplicacionTextBox = new System.Windows.Forms.TextBox();
            this.haplicacionTextBox = new System.Windows.Forms.TextBox();
            this.p1_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p2_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p3_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p4_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p5_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p6_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p7_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p8_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p9_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p10_s1CheckBox = new System.Windows.Forms.CheckBox();
            this.p1_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p2_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p3_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p4_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p5_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p6_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p7_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p8_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p9_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p10_s2CheckBox = new System.Windows.Forms.CheckBox();
            this.p1_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.p2_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.p3_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.p4_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.p5_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.p6_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.p7_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.p8_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.p9_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.p10_s3CheckBox = new System.Windows.Forms.CheckBox();
            this.testexamenDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.correo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultadoLabel1 = new System.Windows.Forms.Label();
            this.materialFlatButton1 = new MaterialSkin.Controls.MaterialFlatButton();
            nombreLabel = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // nombreLabel
            // 
            nombreLabel.AutoSize = true;
            nombreLabel.BackColor = System.Drawing.Color.Transparent;
            nombreLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            nombreLabel.Location = new System.Drawing.Point(869, 83);
            nombreLabel.Name = "nombreLabel";
            nombreLabel.Size = new System.Drawing.Size(62, 16);
            nombreLabel.TabIndex = 158;
            nombreLabel.Text = "Nombre";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = System.Drawing.Color.Transparent;
            label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label7.Location = new System.Drawing.Point(861, 123);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(70, 16);
            label7.TabIndex = 163;
            label7.Text = "Matricula";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = System.Drawing.Color.Transparent;
            label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label8.Location = new System.Drawing.Point(1098, 122);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(164, 16);
            label8.TabIndex = 164;
            label8.Text = "Hora en que se realizo";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = System.Drawing.Color.Transparent;
            label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label9.Location = new System.Drawing.Point(1098, 77);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(236, 16);
            label9.TabIndex = 165;
            label9.Text = "Fecha que se realizo la encuesta";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = System.Drawing.Color.Transparent;
            label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label10.Location = new System.Drawing.Point(598, 96);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(201, 16);
            label10.TabIndex = 167;
            label10.Text = "Inteligencia Obtenida Actual";
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(1051, 659);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(259, 57);
            this.materialRaisedButton1.TabIndex = 156;
            this.materialRaisedButton1.Text = "SECCION 2";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1010, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(279, 25);
            this.label4.TabIndex = 144;
            this.label4.Text = "Inteligencia viso-espacial";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(977, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(324, 25);
            this.label5.TabIndex = 145;
            this.label5.Text = "________________________";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(579, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(331, 25);
            this.label1.TabIndex = 132;
            this.label1.Text = "Inteligencia lógico-matemática";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(535, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(324, 25);
            this.label3.TabIndex = 133;
            this.label3.Text = "________________________";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(78, 203);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(319, 25);
            this.label2.TabIndex = 120;
            this.label2.Text = "Inteligencia verbal lingüística";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(75, 216);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(324, 25);
            this.label11.TabIndex = 121;
            this.label11.Text = "________________________";
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // testexamenBindingSource
            // 
            this.testexamenBindingSource.DataMember = "testexamen";
            this.testexamenBindingSource.DataSource = this.dataSet1;
            // 
            // testexamenTableAdapter
            // 
            this.testexamenTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.testexamenTableAdapter = this.testexamenTableAdapter;
            this.tableAdapterManager.UpdateOrder = Test_Inteligencias_Multiples_2.DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // testexamenBindingSource1
            // 
            this.testexamenBindingSource1.DataMember = "testexamen";
            this.testexamenBindingSource1.DataSource = this.datos;
            // 
            // datos
            // 
            this.datos.DataSetName = "datos";
            this.datos.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // testexamenTableAdapter1
            // 
            this.testexamenTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.testexamenTableAdapter = this.testexamenTableAdapter1;
            this.tableAdapterManager1.UpdateOrder = Test_Inteligencias_Multiples_2.datosTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // nombreTextBox
            // 
            this.nombreTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource1, "nombre", true));
            this.nombreTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombreTextBox.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.nombreTextBox.Location = new System.Drawing.Point(872, 99);
            this.nombreTextBox.Name = "nombreTextBox";
            this.nombreTextBox.Size = new System.Drawing.Size(194, 21);
            this.nombreTextBox.TabIndex = 159;
            // 
            // matriculaTextBox
            // 
            this.matriculaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource1, "matricula", true));
            this.matriculaTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.matriculaTextBox.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.matriculaTextBox.Location = new System.Drawing.Point(872, 139);
            this.matriculaTextBox.Name = "matriculaTextBox";
            this.matriculaTextBox.Size = new System.Drawing.Size(194, 21);
            this.matriculaTextBox.TabIndex = 160;
            // 
            // faplicacionTextBox
            // 
            this.faplicacionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource1, "faplicacion", true));
            this.faplicacionTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faplicacionTextBox.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.faplicacionTextBox.Location = new System.Drawing.Point(1101, 96);
            this.faplicacionTextBox.Name = "faplicacionTextBox";
            this.faplicacionTextBox.Size = new System.Drawing.Size(162, 21);
            this.faplicacionTextBox.TabIndex = 161;
            // 
            // haplicacionTextBox
            // 
            this.haplicacionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource1, "haplicacion", true));
            this.haplicacionTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.haplicacionTextBox.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.haplicacionTextBox.Location = new System.Drawing.Point(1101, 139);
            this.haplicacionTextBox.Name = "haplicacionTextBox";
            this.haplicacionTextBox.Size = new System.Drawing.Size(162, 21);
            this.haplicacionTextBox.TabIndex = 162;
            // 
            // p1_s1CheckBox
            // 
            this.p1_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p1_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p1_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p1_s1", true));
            this.p1_s1CheckBox.Location = new System.Drawing.Point(80, 258);
            this.p1_s1CheckBox.Name = "p1_s1CheckBox";
            this.p1_s1CheckBox.Size = new System.Drawing.Size(319, 24);
            this.p1_s1CheckBox.TabIndex = 168;
            this.p1_s1CheckBox.Text = "Los libros son muy importantes para mí.";
            this.p1_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p2_s1CheckBox
            // 
            this.p2_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p2_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p2_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p2_s1", true));
            this.p2_s1CheckBox.Location = new System.Drawing.Point(80, 288);
            this.p2_s1CheckBox.Name = "p2_s1CheckBox";
            this.p2_s1CheckBox.Size = new System.Drawing.Size(319, 34);
            this.p2_s1CheckBox.TabIndex = 169;
            this.p2_s1CheckBox.Text = "Oigo las palabras en mi mente antes de leer, hablar o escribirlas.";
            this.p2_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p3_s1CheckBox
            // 
            this.p3_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p3_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p3_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p3_s1", true));
            this.p3_s1CheckBox.Location = new System.Drawing.Point(80, 328);
            this.p3_s1CheckBox.Name = "p3_s1CheckBox";
            this.p3_s1CheckBox.Size = new System.Drawing.Size(319, 35);
            this.p3_s1CheckBox.TabIndex = 170;
            this.p3_s1CheckBox.Text = "Me aportan más la radio o unas cintas grabada que la televisión o las películas.";
            this.p3_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p4_s1CheckBox
            // 
            this.p4_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p4_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p4_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p4_s1", true));
            this.p4_s1CheckBox.Location = new System.Drawing.Point(80, 368);
            this.p4_s1CheckBox.Name = "p4_s1CheckBox";
            this.p4_s1CheckBox.Size = new System.Drawing.Size(319, 35);
            this.p4_s1CheckBox.TabIndex = 171;
            this.p4_s1CheckBox.Text = "Me gustan los juegos de palabras como el Scrabble, el Anagrams o el Password.";
            this.p4_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p5_s1CheckBox
            // 
            this.p5_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p5_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p5_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p5_s1", true));
            this.p5_s1CheckBox.Location = new System.Drawing.Point(80, 409);
            this.p5_s1CheckBox.Name = "p5_s1CheckBox";
            this.p5_s1CheckBox.Size = new System.Drawing.Size(319, 35);
            this.p5_s1CheckBox.TabIndex = 172;
            this.p5_s1CheckBox.Text = "Me gusta entretenerme o entretener a los demás con trabalenguas, rimas absurdas o" +
    " juegos de palabras.";
            this.p5_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p6_s1CheckBox
            // 
            this.p6_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p6_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p6_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p6_s1", true));
            this.p6_s1CheckBox.Location = new System.Drawing.Point(80, 449);
            this.p6_s1CheckBox.Name = "p6_s1CheckBox";
            this.p6_s1CheckBox.Size = new System.Drawing.Size(319, 35);
            this.p6_s1CheckBox.TabIndex = 173;
            this.p6_s1CheckBox.Text = "En ocasiones, algunas personas me piden que les explique el significado de las pa" +
    "labras que utilizo (escritas u orales).";
            this.p6_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p7_s1CheckBox
            // 
            this.p7_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p7_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p7_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p7_s1", true));
            this.p7_s1CheckBox.Location = new System.Drawing.Point(80, 487);
            this.p7_s1CheckBox.Name = "p7_s1CheckBox";
            this.p7_s1CheckBox.Size = new System.Drawing.Size(319, 35);
            this.p7_s1CheckBox.TabIndex = 174;
            this.p7_s1CheckBox.Text = "En el cole asimilaba mejor la lengua y la literatura, las ciencias sociales y la " +
    "historia que las mates y las ciencias naturales.";
            this.p7_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p8_s1CheckBox
            // 
            this.p8_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p8_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p8_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p8_s1", true));
            this.p8_s1CheckBox.Location = new System.Drawing.Point(80, 525);
            this.p8_s1CheckBox.Name = "p8_s1CheckBox";
            this.p8_s1CheckBox.Size = new System.Drawing.Size(319, 35);
            this.p8_s1CheckBox.TabIndex = 175;
            this.p8_s1CheckBox.Text = "Aprender a hablar o leer otra lengua (inglés, francés o alemán, por ejemplo) me r" +
    "esulta relaMi conversación incluye referencias frecuentes a datos que he leído o" +
    " escuchado.tivamente sencillo.";
            this.p8_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p9_s1CheckBox
            // 
            this.p9_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p9_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p9_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p9_s1", true));
            this.p9_s1CheckBox.Location = new System.Drawing.Point(80, 563);
            this.p9_s1CheckBox.Name = "p9_s1CheckBox";
            this.p9_s1CheckBox.Size = new System.Drawing.Size(319, 35);
            this.p9_s1CheckBox.TabIndex = 176;
            this.p9_s1CheckBox.Text = "Mi conversación incluye referencias frecuentes a datos que he leído o escuchado.";
            this.p9_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p10_s1CheckBox
            // 
            this.p10_s1CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p10_s1CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p10_s1CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p10_s1", true));
            this.p10_s1CheckBox.Location = new System.Drawing.Point(80, 600);
            this.p10_s1CheckBox.Name = "p10_s1CheckBox";
            this.p10_s1CheckBox.Size = new System.Drawing.Size(319, 35);
            this.p10_s1CheckBox.TabIndex = 177;
            this.p10_s1CheckBox.Text = "Recientemente he escrito algo de lo que estoy especialmente.";
            this.p10_s1CheckBox.UseVisualStyleBackColor = false;
            // 
            // p1_s2CheckBox
            // 
            this.p1_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p1_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p1_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p1_s2", true));
            this.p1_s2CheckBox.Location = new System.Drawing.Point(540, 258);
            this.p1_s2CheckBox.Name = "p1_s2CheckBox";
            this.p1_s2CheckBox.Size = new System.Drawing.Size(319, 24);
            this.p1_s2CheckBox.TabIndex = 178;
            this.p1_s2CheckBox.Text = "Soy capaz de calcular operaciones mentalmente sin esfuerzo.";
            this.p1_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p2_s2CheckBox
            // 
            this.p2_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p2_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p2_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p2_s2", true));
            this.p2_s2CheckBox.Location = new System.Drawing.Point(540, 288);
            this.p2_s2CheckBox.Name = "p2_s2CheckBox";
            this.p2_s2CheckBox.Size = new System.Drawing.Size(319, 38);
            this.p2_s2CheckBox.TabIndex = 179;
            this.p2_s2CheckBox.Text = "Las matemáticas y/o las ciencias figuraban entre mis asignaturas favoritas en el " +
    "colegio.";
            this.p2_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p3_s2CheckBox
            // 
            this.p3_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p3_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p3_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p3_s2", true));
            this.p3_s2CheckBox.Location = new System.Drawing.Point(540, 328);
            this.p3_s2CheckBox.Name = "p3_s2CheckBox";
            this.p3_s2CheckBox.Size = new System.Drawing.Size(319, 34);
            this.p3_s2CheckBox.TabIndex = 180;
            this.p3_s2CheckBox.Text = "Me gustan los juegos o los acertijos que requieren un pensamiento lógico.";
            this.p3_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p4_s2CheckBox
            // 
            this.p4_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p4_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p4_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p4_s2", true));
            this.p4_s2CheckBox.Location = new System.Drawing.Point(540, 368);
            this.p4_s2CheckBox.Name = "p4_s2CheckBox";
            this.p4_s2CheckBox.Size = new System.Drawing.Size(319, 35);
            this.p4_s2CheckBox.TabIndex = 181;
            this.p4_s2CheckBox.Text = "checkBoMe gusta realizar pequeños experimentos del tipo «¿Qué pasaría si...?";
            this.p4_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p5_s2CheckBox
            // 
            this.p5_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p5_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p5_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p5_s2", true));
            this.p5_s2CheckBox.Location = new System.Drawing.Point(540, 409);
            this.p5_s2CheckBox.Name = "p5_s2CheckBox";
            this.p5_s2CheckBox.Size = new System.Drawing.Size(319, 31);
            this.p5_s2CheckBox.TabIndex = 182;
            this.p5_s2CheckBox.Text = "Mi mente busca patrones, regularidad o secuencias lógicas en las cosas.";
            this.p5_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p6_s2CheckBox
            // 
            this.p6_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p6_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p6_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p6_s2", true));
            this.p6_s2CheckBox.Location = new System.Drawing.Point(540, 446);
            this.p6_s2CheckBox.Name = "p6_s2CheckBox";
            this.p6_s2CheckBox.Size = new System.Drawing.Size(319, 24);
            this.p6_s2CheckBox.TabIndex = 183;
            this.p6_s2CheckBox.Text = "Me interesan los avances científicos.";
            this.p6_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p7_s2CheckBox
            // 
            this.p7_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p7_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p7_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p7_s2", true));
            this.p7_s2CheckBox.Location = new System.Drawing.Point(540, 486);
            this.p7_s2CheckBox.Name = "p7_s2CheckBox";
            this.p7_s2CheckBox.Size = new System.Drawing.Size(319, 24);
            this.p7_s2CheckBox.TabIndex = 184;
            this.p7_s2CheckBox.Text = "Creo que casi todo tiene una explicación racional.";
            this.p7_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p8_s2CheckBox
            // 
            this.p8_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p8_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p8_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p8_s2", true));
            this.p8_s2CheckBox.Location = new System.Drawing.Point(540, 527);
            this.p8_s2CheckBox.Name = "p8_s2CheckBox";
            this.p8_s2CheckBox.Size = new System.Drawing.Size(319, 24);
            this.p8_s2CheckBox.TabIndex = 185;
            this.p8_s2CheckBox.Text = "En ocasiones pienso en conceptos claros, abstractos, sin palabras ni imágenes.";
            this.p8_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p9_s2CheckBox
            // 
            this.p9_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p9_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p9_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p9_s2", true));
            this.p9_s2CheckBox.Location = new System.Drawing.Point(540, 558);
            this.p9_s2CheckBox.Name = "p9_s2CheckBox";
            this.p9_s2CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p9_s2CheckBox.TabIndex = 186;
            this.p9_s2CheckBox.Text = "Me gusta detectar defectos lógicos en las cosas que la gente dice y hace en casa " +
    "y en el trabajo";
            this.p9_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p10_s2CheckBox
            // 
            this.p10_s2CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p10_s2CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p10_s2CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p10_s2", true));
            this.p10_s2CheckBox.Location = new System.Drawing.Point(540, 608);
            this.p10_s2CheckBox.Name = "p10_s2CheckBox";
            this.p10_s2CheckBox.Size = new System.Drawing.Size(319, 32);
            this.p10_s2CheckBox.TabIndex = 187;
            this.p10_s2CheckBox.Text = "Me siento más cómodo cuando las cosas están medidas, categorizar las, analizadas " +
    "o cuantificadas de algún modo.";
            this.p10_s2CheckBox.UseVisualStyleBackColor = false;
            // 
            // p1_s3CheckBox
            // 
            this.p1_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p1_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p1_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p1_s3", true));
            this.p1_s3CheckBox.Location = new System.Drawing.Point(982, 241);
            this.p1_s3CheckBox.Name = "p1_s3CheckBox";
            this.p1_s3CheckBox.Size = new System.Drawing.Size(339, 30);
            this.p1_s3CheckBox.TabIndex = 188;
            this.p1_s3CheckBox.Text = "Cuando cierro los ojos percibo imágenes visuales claras.";
            this.p1_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // p2_s3CheckBox
            // 
            this.p2_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p2_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p2_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p2_s3", true));
            this.p2_s3CheckBox.Location = new System.Drawing.Point(982, 280);
            this.p2_s3CheckBox.Name = "p2_s3CheckBox";
            this.p2_s3CheckBox.Size = new System.Drawing.Size(339, 30);
            this.p2_s3CheckBox.TabIndex = 189;
            this.p2_s3CheckBox.Text = "Soy sensible al color.";
            this.p2_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // p3_s3CheckBox
            // 
            this.p3_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p3_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p3_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p3_s3", true));
            this.p3_s3CheckBox.Location = new System.Drawing.Point(982, 317);
            this.p3_s3CheckBox.Name = "p3_s3CheckBox";
            this.p3_s3CheckBox.Size = new System.Drawing.Size(339, 34);
            this.p3_s3CheckBox.TabIndex = 190;
            this.p3_s3CheckBox.Text = "Habitualmente utilizo una cámara de fotos o una videocámara para captar lo que ve" +
    "o a mi alrededor.";
            this.p3_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // p4_s3CheckBox
            // 
            this.p4_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p4_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p4_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p4_s3", true));
            this.p4_s3CheckBox.Location = new System.Drawing.Point(982, 358);
            this.p4_s3CheckBox.Name = "p4_s3CheckBox";
            this.p4_s3CheckBox.Size = new System.Drawing.Size(339, 35);
            this.p4_s3CheckBox.TabIndex = 191;
            this.p4_s3CheckBox.Text = "Me gustan los rompecabezas, los laberintos y demás juegos visuales.";
            this.p4_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // p5_s3CheckBox
            // 
            this.p5_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p5_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p5_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p5_s3", true));
            this.p5_s3CheckBox.Location = new System.Drawing.Point(982, 401);
            this.p5_s3CheckBox.Name = "p5_s3CheckBox";
            this.p5_s3CheckBox.Size = new System.Drawing.Size(339, 30);
            this.p5_s3CheckBox.TabIndex = 192;
            this.p5_s3CheckBox.Text = "Por la noche tengo sueños muy intensos.";
            this.p5_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // p6_s3CheckBox
            // 
            this.p6_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p6_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p6_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p6_s3", true));
            this.p6_s3CheckBox.Location = new System.Drawing.Point(982, 438);
            this.p6_s3CheckBox.Name = "p6_s3CheckBox";
            this.p6_s3CheckBox.Size = new System.Drawing.Size(339, 30);
            this.p6_s3CheckBox.TabIndex = 193;
            this.p6_s3CheckBox.Text = "En general, soy capaz de orientarme en un lugar desconocido.";
            this.p6_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // p7_s3CheckBox
            // 
            this.p7_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p7_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p7_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p7_s3", true));
            this.p7_s3CheckBox.Location = new System.Drawing.Point(982, 478);
            this.p7_s3CheckBox.Name = "p7_s3CheckBox";
            this.p7_s3CheckBox.Size = new System.Drawing.Size(339, 30);
            this.p7_s3CheckBox.TabIndex = 194;
            this.p7_s3CheckBox.Text = "Me gusta dibujar o garabatear.";
            this.p7_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // p8_s3CheckBox
            // 
            this.p8_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p8_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p8_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p8_s3", true));
            this.p8_s3CheckBox.Location = new System.Drawing.Point(982, 519);
            this.p8_s3CheckBox.Name = "p8_s3CheckBox";
            this.p8_s3CheckBox.Size = new System.Drawing.Size(339, 30);
            this.p8_s3CheckBox.TabIndex = 195;
            this.p8_s3CheckBox.Text = "En el colegio me costaba menos la geometría que el álgebra.";
            this.p8_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // p9_s3CheckBox
            // 
            this.p9_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p9_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p9_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p9_s3", true));
            this.p9_s3CheckBox.Location = new System.Drawing.Point(982, 563);
            this.p9_s3CheckBox.Name = "p9_s3CheckBox";
            this.p9_s3CheckBox.Size = new System.Drawing.Size(339, 30);
            this.p9_s3CheckBox.TabIndex = 196;
            this.p9_s3CheckBox.Text = "Me puedo imaginar sin ningún esfuerzo el aspecto que tendría las cosas vistas des" +
    "de arriba.";
            this.p9_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // p10_s3CheckBox
            // 
            this.p10_s3CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p10_s3CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p10_s3CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource1, "p10_s3", true));
            this.p10_s3CheckBox.Location = new System.Drawing.Point(982, 606);
            this.p10_s3CheckBox.Name = "p10_s3CheckBox";
            this.p10_s3CheckBox.Size = new System.Drawing.Size(339, 30);
            this.p10_s3CheckBox.TabIndex = 197;
            this.p10_s3CheckBox.Text = "Prefiero el material de lectura con muchas ilustraciones.";
            this.p10_s3CheckBox.UseVisualStyleBackColor = false;
            // 
            // testexamenDataGridView
            // 
            this.testexamenDataGridView.AutoGenerateColumns = false;
            this.testexamenDataGridView.BackgroundColor = System.Drawing.Color.IndianRed;
            this.testexamenDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.testexamenDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.testexamenDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.testexamenDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.correo,
            this.dataGridViewTextBoxColumn2});
            this.testexamenDataGridView.Cursor = System.Windows.Forms.Cursors.Hand;
            this.testexamenDataGridView.DataSource = this.testexamenBindingSource1;
            this.testexamenDataGridView.GridColor = System.Drawing.Color.IndianRed;
            this.testexamenDataGridView.Location = new System.Drawing.Point(22, 75);
            this.testexamenDataGridView.Name = "testexamenDataGridView";
            this.testexamenDataGridView.Size = new System.Drawing.Size(524, 109);
            this.testexamenDataGridView.TabIndex = 198;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "matricula";
            this.dataGridViewTextBoxColumn1.HeaderText = "MATRICULA";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 120;
            // 
            // correo
            // 
            this.correo.DataPropertyName = "correo";
            this.correo.HeaderText = "CORREO ELECTRONICO";
            this.correo.Name = "correo";
            this.correo.Width = 180;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nombre";
            this.dataGridViewTextBoxColumn2.HeaderText = "NOMBRE COMPLETO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 180;
            // 
            // resultadoLabel1
            // 
            this.resultadoLabel1.BackColor = System.Drawing.Color.Transparent;
            this.resultadoLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource1, "resultado", true));
            this.resultadoLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultadoLabel1.ForeColor = System.Drawing.Color.ForestGreen;
            this.resultadoLabel1.Location = new System.Drawing.Point(570, 116);
            this.resultadoLabel1.Name = "resultadoLabel1";
            this.resultadoLabel1.Size = new System.Drawing.Size(285, 57);
            this.resultadoLabel1.TabIndex = 199;
            this.resultadoLabel1.Text = "Inteligencias";
            this.resultadoLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // materialFlatButton1
            // 
            this.materialFlatButton1.AutoSize = true;
            this.materialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialFlatButton1.Depth = 0;
            this.materialFlatButton1.Location = new System.Drawing.Point(80, 680);
            this.materialFlatButton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialFlatButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialFlatButton1.Name = "materialFlatButton1";
            this.materialFlatButton1.Primary = false;
            this.materialFlatButton1.Size = new System.Drawing.Size(143, 36);
            this.materialFlatButton1.TabIndex = 200;
            this.materialFlatButton1.Text = "Volver a Registro";
            this.materialFlatButton1.UseVisualStyleBackColor = true;
            this.materialFlatButton1.Click += new System.EventHandler(this.materialFlatButton1_Click);
            // 
            // Modifica1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.materialFlatButton1);
            this.Controls.Add(this.resultadoLabel1);
            this.Controls.Add(this.testexamenDataGridView);
            this.Controls.Add(this.p10_s3CheckBox);
            this.Controls.Add(this.p9_s3CheckBox);
            this.Controls.Add(this.p8_s3CheckBox);
            this.Controls.Add(this.p7_s3CheckBox);
            this.Controls.Add(this.p6_s3CheckBox);
            this.Controls.Add(this.p5_s3CheckBox);
            this.Controls.Add(this.p4_s3CheckBox);
            this.Controls.Add(this.p3_s3CheckBox);
            this.Controls.Add(this.p2_s3CheckBox);
            this.Controls.Add(this.p1_s3CheckBox);
            this.Controls.Add(this.p10_s2CheckBox);
            this.Controls.Add(this.p9_s2CheckBox);
            this.Controls.Add(this.p8_s2CheckBox);
            this.Controls.Add(this.p7_s2CheckBox);
            this.Controls.Add(this.p6_s2CheckBox);
            this.Controls.Add(this.p5_s2CheckBox);
            this.Controls.Add(this.p4_s2CheckBox);
            this.Controls.Add(this.p3_s2CheckBox);
            this.Controls.Add(this.p2_s2CheckBox);
            this.Controls.Add(this.p1_s2CheckBox);
            this.Controls.Add(this.p10_s1CheckBox);
            this.Controls.Add(this.p9_s1CheckBox);
            this.Controls.Add(this.p8_s1CheckBox);
            this.Controls.Add(this.p7_s1CheckBox);
            this.Controls.Add(this.p6_s1CheckBox);
            this.Controls.Add(this.p5_s1CheckBox);
            this.Controls.Add(this.p4_s1CheckBox);
            this.Controls.Add(this.p3_s1CheckBox);
            this.Controls.Add(this.p2_s1CheckBox);
            this.Controls.Add(this.p1_s1CheckBox);
            this.Controls.Add(label10);
            this.Controls.Add(label9);
            this.Controls.Add(label8);
            this.Controls.Add(label7);
            this.Controls.Add(this.haplicacionTextBox);
            this.Controls.Add(this.faplicacionTextBox);
            this.Controls.Add(this.matriculaTextBox);
            this.Controls.Add(nombreLabel);
            this.Controls.Add(this.nombreTextBox);
            this.Controls.Add(this.materialRaisedButton1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Name = "Modifica1";
            this.Text = "Modifica1";
            this.Load += new System.EventHandler(this.Modifica1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource testexamenBindingSource;
        private DataSet1TableAdapters.testexamenTableAdapter testexamenTableAdapter;
        private DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox nombreTextBox;
        private System.Windows.Forms.TextBox matriculaTextBox;
        private System.Windows.Forms.TextBox faplicacionTextBox;
        private System.Windows.Forms.TextBox haplicacionTextBox;
        private System.Windows.Forms.CheckBox p1_s1CheckBox;
        private System.Windows.Forms.CheckBox p2_s1CheckBox;
        private System.Windows.Forms.CheckBox p3_s1CheckBox;
        private System.Windows.Forms.CheckBox p4_s1CheckBox;
        private System.Windows.Forms.CheckBox p5_s1CheckBox;
        private System.Windows.Forms.CheckBox p6_s1CheckBox;
        private System.Windows.Forms.CheckBox p7_s1CheckBox;
        private System.Windows.Forms.CheckBox p8_s1CheckBox;
        private System.Windows.Forms.CheckBox p9_s1CheckBox;
        private System.Windows.Forms.CheckBox p10_s1CheckBox;
        private System.Windows.Forms.CheckBox p1_s2CheckBox;
        private System.Windows.Forms.CheckBox p2_s2CheckBox;
        private System.Windows.Forms.CheckBox p3_s2CheckBox;
        private System.Windows.Forms.CheckBox p4_s2CheckBox;
        private System.Windows.Forms.CheckBox p5_s2CheckBox;
        private System.Windows.Forms.CheckBox p6_s2CheckBox;
        private System.Windows.Forms.CheckBox p7_s2CheckBox;
        private System.Windows.Forms.CheckBox p8_s2CheckBox;
        private System.Windows.Forms.CheckBox p9_s2CheckBox;
        private System.Windows.Forms.CheckBox p10_s2CheckBox;
        private System.Windows.Forms.CheckBox p1_s3CheckBox;
        private System.Windows.Forms.CheckBox p2_s3CheckBox;
        private System.Windows.Forms.CheckBox p3_s3CheckBox;
        private System.Windows.Forms.CheckBox p4_s3CheckBox;
        private System.Windows.Forms.CheckBox p5_s3CheckBox;
        private System.Windows.Forms.CheckBox p6_s3CheckBox;
        private System.Windows.Forms.CheckBox p7_s3CheckBox;
        private System.Windows.Forms.CheckBox p8_s3CheckBox;
        private System.Windows.Forms.CheckBox p9_s3CheckBox;
        private System.Windows.Forms.CheckBox p10_s3CheckBox;
        private System.Windows.Forms.DataGridView testexamenDataGridView;
        private System.Windows.Forms.Label resultadoLabel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn correo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private MaterialSkin.Controls.MaterialFlatButton materialFlatButton1;
        public datos datos;
        public System.Windows.Forms.BindingSource testexamenBindingSource1;
        public datosTableAdapters.testexamenTableAdapter testexamenTableAdapter1;
        public datosTableAdapters.TableAdapterManager tableAdapterManager1;
    }
}