﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Modifica1 : MaterialSkin.Controls.MaterialForm
    {
         int resultados1;
         int resultados2;
         int resultados3;

        public Modifica1()
        {
            InitializeComponent();
        }

        private void Modifica1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'datos.testexamen' Puede moverla o quitarla según sea necesario.
            this.testexamenTableAdapter1.Fill(this.datos.testexamen);
            // TODO: esta línea de código carga datos en la tabla 'dataSet1.testexamen' Puede moverla o quitarla según sea necesario.
            this.testexamenTableAdapter.Fill(this.dataSet1.testexamen);

            nombreTextBox.Enabled = false;
            matriculaTextBox.Enabled = false;
            faplicacionTextBox.Enabled = false;
            haplicacionTextBox.Enabled = false;

        }

        private void testexamenBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.testexamenBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet1);

        }

        private void correoComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.testexamenTableAdapter1.FillBy(this.datos.testexamen);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            if (p1_s1CheckBox.Checked == true )
            {
                resultados1 += 1;
            }
            if (p2_s1CheckBox.Checked == true)
            {
                resultados1 += 1;
            }
            if (p3_s1CheckBox.Checked == true)
            {
                resultados1 += 1;
            }
            if (p4_s1CheckBox.Checked == true)
            {
                resultados1 += 1;
            }
            if (p5_s1CheckBox.Checked == true)
            {
                resultados1 += 1;
            }
            if (p6_s1CheckBox.Checked == true)
            {
                resultados1 += 1;
            }
            if (p7_s1CheckBox.Checked == true)
            {
                resultados1 += 1;
            }
            if (p8_s1CheckBox.Checked == true)
            {
                resultados1 += 1;
            }
            if (p9_s1CheckBox.Checked == true)
            {
                resultados1 += 1;
            }
            if (p10_s1CheckBox.Checked == true)
            {
                resultados1 += 1;
            }



            if (p1_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }
            if (p2_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }
            if (p3_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }
            if (p4_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }
            if (p5_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }
            if (p6_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }
            if (p7_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }
            if (p8_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }
            if (p9_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }
            if (p10_s2CheckBox.Checked == true)
            {
                resultados2 += 1;
            }



            if (p1_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }
            if (p2_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }
            if (p3_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }
            if (p4_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }
            if (p5_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }
            if (p6_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }
            if (p7_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }
            if (p8_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }
            if (p9_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }
            if (p10_s3CheckBox.Checked == true)
            {
                resultados3 += 1;
            }

            Seccion1 s1 = new Seccion1();
            s1.Matricula = Convert.ToInt32(matriculaTextBox.Text);
            s1.p1_s1 = p1_s1CheckBox.Checked;
            s1.p2_s1 = p2_s1CheckBox.Checked;
            s1.p3_s1 = p3_s1CheckBox.Checked;
            s1.p4_s1 = p4_s1CheckBox.Checked;
            s1.p5_s1 = p5_s1CheckBox.Checked;
            s1.p6_s1 = p6_s1CheckBox.Checked;
            s1.p7_s1 = p7_s1CheckBox.Checked;
            s1.p8_s1 = p8_s1CheckBox.Checked;
            s1.p9_s1 = p9_s1CheckBox.Checked;
            s1.p10_s1 = p10_s1CheckBox.Checked;


            Seccion2 s2 = new Seccion2();
            s2.Matricula = Convert.ToInt32(matriculaTextBox.Text);
            s2.p1_s2 = p1_s2CheckBox.Checked;
            s2.p2_s2 = p2_s2CheckBox.Checked;
            s2.p3_s2 = p3_s2CheckBox.Checked;
            s2.p4_s2 = p4_s2CheckBox.Checked;
            s2.p5_s2 = p5_s2CheckBox.Checked;
            s2.p6_s2 = p6_s2CheckBox.Checked;
            s2.p7_s2 = p7_s2CheckBox.Checked;
            s2.p8_s2 = p8_s2CheckBox.Checked;
            s2.p9_s2 = p9_s2CheckBox.Checked;
            s2.p10_s2 = p10_s2CheckBox.Checked;

            Seccion3 s3 = new Seccion3();
            s3.Matricula = Convert.ToInt32(matriculaTextBox.Text);
            s3.p1_s3 = p1_s3CheckBox.Checked;
            s3.p2_s3 = p2_s3CheckBox.Checked;
            s3.p3_s3 = p3_s3CheckBox.Checked;
            s3.p4_s3 = p4_s3CheckBox.Checked;
            s3.p5_s3 = p5_s3CheckBox.Checked;
            s3.p6_s3 = p6_s3CheckBox.Checked;
            s3.p7_s3 = p7_s3CheckBox.Checked;
            s3.p8_s3 = p8_s3CheckBox.Checked;
            s3.p9_s3 = p9_s3CheckBox.Checked;
            s3.p10_s3 = p10_s3CheckBox.Checked;


            int resultado = EncuestadoDAO.Seccion2(s2);
            int resultado2 = EncuestadoDAO.Seccion1(s1);
            int resultado3 = EncuestadoDAO.Seccion3(s3);

            string mm = matriculaTextBox.Text;


            Modifica2 m2 = new Modifica2(resultados1,resultados2,resultados3,matriculaTextBox.Text);
            m2.Show();
            this.Hide();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            Registro r1 = new Registro();
            r1.Show();
            this.Hide();

        }
    }
}
