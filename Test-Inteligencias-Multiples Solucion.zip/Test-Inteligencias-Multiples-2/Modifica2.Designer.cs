﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Modifica2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.datos = new Test_Inteligencias_Multiples_2.datos();
            this.testexamenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testexamenTableAdapter = new Test_Inteligencias_Multiples_2.datosTableAdapters.testexamenTableAdapter();
            this.tableAdapterManager = new Test_Inteligencias_Multiples_2.datosTableAdapters.TableAdapterManager();
            this.p1_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p2_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p3_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p4_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p5_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p6_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p7_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p8_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p9_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p10_s4CheckBox = new System.Windows.Forms.CheckBox();
            this.p2_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p1_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p3_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p4_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p5_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p6_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p7_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p8_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p9_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p10_s5CheckBox = new System.Windows.Forms.CheckBox();
            this.p1_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.p2_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.p3_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.p4_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.p5_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.p6_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.p7_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.p8_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.p9_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.p10_s6CheckBox = new System.Windows.Forms.CheckBox();
            this.matriculaTextBox = new System.Windows.Forms.TextBox();
            this.correoComboBox = new System.Windows.Forms.ComboBox();
            this.testexamenDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.datos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(969, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(278, 25);
            this.label4.TabIndex = 107;
            this.label4.Text = "Inteligencia interpersonal";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(966, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(324, 25);
            this.label5.TabIndex = 108;
            this.label5.Text = "________________________";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(584, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 25);
            this.label1.TabIndex = 95;
            this.label1.Text = "Inteligencia musical";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(521, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(324, 25);
            this.label3.TabIndex = 96;
            this.label3.Text = "________________________";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(59, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(316, 25);
            this.label2.TabIndex = 83;
            this.label2.Text = "Inteligencia cinético-corporal";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(56, 152);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(324, 25);
            this.label11.TabIndex = 84;
            this.label11.Text = "________________________";
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(1043, 655);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(259, 57);
            this.materialRaisedButton1.TabIndex = 119;
            this.materialRaisedButton1.Text = "SECCION 3";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // datos
            // 
            this.datos.DataSetName = "datos";
            this.datos.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // testexamenBindingSource
            // 
            this.testexamenBindingSource.DataMember = "testexamen";
            this.testexamenBindingSource.DataSource = this.datos;
            // 
            // testexamenTableAdapter
            // 
            this.testexamenTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.testexamenTableAdapter = this.testexamenTableAdapter;
            this.tableAdapterManager.UpdateOrder = Test_Inteligencias_Multiples_2.datosTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // p1_s4CheckBox
            // 
            this.p1_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p1_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p1_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p1_s4", true));
            this.p1_s4CheckBox.Location = new System.Drawing.Point(59, 202);
            this.p1_s4CheckBox.Name = "p1_s4CheckBox";
            this.p1_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p1_s4CheckBox.TabIndex = 121;
            this.p1_s4CheckBox.Text = "Practico al menos un deporte o algún tipo de actividad física de forma regular.";
            this.p1_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p2_s4CheckBox
            // 
            this.p2_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p2_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p2_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p2_s4", true));
            this.p2_s4CheckBox.Location = new System.Drawing.Point(59, 244);
            this.p2_s4CheckBox.Name = "p2_s4CheckBox";
            this.p2_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p2_s4CheckBox.TabIndex = 122;
            this.p2_s4CheckBox.Text = "Me cuesta permanecer quieto durante mucho tiempo.";
            this.p2_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p3_s4CheckBox
            // 
            this.p3_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p3_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p3_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p3_s4", true));
            this.p3_s4CheckBox.Location = new System.Drawing.Point(59, 286);
            this.p3_s4CheckBox.Name = "p3_s4CheckBox";
            this.p3_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p3_s4CheckBox.TabIndex = 123;
            this.p3_s4CheckBox.Text = "cheMe gusta trabajar con las manos en actividades concretas como tejer, tallar, c" +
    "arpintería o construcción de maquetas.ckBox1";
            this.p3_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p4_s4CheckBox
            // 
            this.p4_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p4_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p4_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p4_s4", true));
            this.p4_s4CheckBox.Location = new System.Drawing.Point(59, 330);
            this.p4_s4CheckBox.Name = "p4_s4CheckBox";
            this.p4_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p4_s4CheckBox.TabIndex = 124;
            this.p4_s4CheckBox.Text = "En general, las mejores ideas se me ocurren cuando estoy paseando, corriendo o mi" +
    "entras realizo actividades físicas.";
            this.p4_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p5_s4CheckBox
            // 
            this.p5_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p5_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p5_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p5_s4", true));
            this.p5_s4CheckBox.Location = new System.Drawing.Point(59, 372);
            this.p5_s4CheckBox.Name = "p5_s4CheckBox";
            this.p5_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p5_s4CheckBox.TabIndex = 125;
            this.p5_s4CheckBox.Text = "Me gusta pasar mi tiempo de ocio al aire libre.";
            this.p5_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p6_s4CheckBox
            // 
            this.p6_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p6_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p6_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p6_s4", true));
            this.p6_s4CheckBox.Location = new System.Drawing.Point(59, 414);
            this.p6_s4CheckBox.Name = "p6_s4CheckBox";
            this.p6_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p6_s4CheckBox.TabIndex = 126;
            this.p6_s4CheckBox.Text = "Acostumbro a gesticular mucho o a utilizar otras formas de lenguaje corporal cuan" +
    "do hablo con alguien.";
            this.p6_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p7_s4CheckBox
            // 
            this.p7_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p7_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p7_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p7_s4", true));
            this.p7_s4CheckBox.Location = new System.Drawing.Point(59, 456);
            this.p7_s4CheckBox.Name = "p7_s4CheckBox";
            this.p7_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p7_s4CheckBox.TabIndex = 127;
            this.p7_s4CheckBox.Text = "Necesito tocar las cosas para saber más sobre ellas.";
            this.p7_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p8_s4CheckBox
            // 
            this.p8_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p8_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p8_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p8_s4", true));
            this.p8_s4CheckBox.Location = new System.Drawing.Point(59, 502);
            this.p8_s4CheckBox.Name = "p8_s4CheckBox";
            this.p8_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p8_s4CheckBox.TabIndex = 128;
            this.p8_s4CheckBox.Text = "Me gustan las atracciones fuertes y las experiencias físicas emocionantes.";
            this.p8_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p9_s4CheckBox
            // 
            this.p9_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p9_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p9_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p9_s4", true));
            this.p9_s4CheckBox.Location = new System.Drawing.Point(59, 544);
            this.p9_s4CheckBox.Name = "p9_s4CheckBox";
            this.p9_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p9_s4CheckBox.TabIndex = 129;
            this.p9_s4CheckBox.Text = "Creo que soy una o persona con una buena coordinación.";
            this.p9_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p10_s4CheckBox
            // 
            this.p10_s4CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p10_s4CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p10_s4CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p10_s4", true));
            this.p10_s4CheckBox.Location = new System.Drawing.Point(59, 586);
            this.p10_s4CheckBox.Name = "p10_s4CheckBox";
            this.p10_s4CheckBox.Size = new System.Drawing.Size(316, 36);
            this.p10_s4CheckBox.TabIndex = 130;
            this.p10_s4CheckBox.Text = "No me basta con leer información o ver un vídeo sobre una nueva actividad: necesi" +
    "to practicarla.";
            this.p10_s4CheckBox.UseVisualStyleBackColor = false;
            // 
            // p2_s5CheckBox
            // 
            this.p2_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p2_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p2_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p2_s5", true));
            this.p2_s5CheckBox.Location = new System.Drawing.Point(526, 244);
            this.p2_s5CheckBox.Name = "p2_s5CheckBox";
            this.p2_s5CheckBox.Size = new System.Drawing.Size(330, 24);
            this.p2_s5CheckBox.TabIndex = 131;
            this.p2_s5CheckBox.Text = "Percibo cuando una nota musical está desafinada.";
            this.p2_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p1_s5CheckBox
            // 
            this.p1_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p1_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p1_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p1_s5", true));
            this.p1_s5CheckBox.Location = new System.Drawing.Point(526, 202);
            this.p1_s5CheckBox.Name = "p1_s5CheckBox";
            this.p1_s5CheckBox.Size = new System.Drawing.Size(330, 24);
            this.p1_s5CheckBox.TabIndex = 132;
            this.p1_s5CheckBox.Text = "Una voz agradable.";
            this.p1_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p3_s5CheckBox
            // 
            this.p3_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p3_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p3_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p3_s5", true));
            this.p3_s5CheckBox.Location = new System.Drawing.Point(526, 286);
            this.p3_s5CheckBox.Name = "p3_s5CheckBox";
            this.p3_s5CheckBox.Size = new System.Drawing.Size(330, 24);
            this.p3_s5CheckBox.TabIndex = 133;
            this.p3_s5CheckBox.Text = "Siempre estoy escuchando música.";
            this.p3_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p4_s5CheckBox
            // 
            this.p4_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p4_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p4_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p4_s5", true));
            this.p4_s5CheckBox.Location = new System.Drawing.Point(526, 330);
            this.p4_s5CheckBox.Name = "p4_s5CheckBox";
            this.p4_s5CheckBox.Size = new System.Drawing.Size(330, 24);
            this.p4_s5CheckBox.TabIndex = 134;
            this.p4_s5CheckBox.Text = "Tocó un instrumento musical.";
            this.p4_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p5_s5CheckBox
            // 
            this.p5_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p5_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p5_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p5_s5", true));
            this.p5_s5CheckBox.Location = new System.Drawing.Point(526, 378);
            this.p5_s5CheckBox.Name = "p5_s5CheckBox";
            this.p5_s5CheckBox.Size = new System.Drawing.Size(330, 24);
            this.p5_s5CheckBox.TabIndex = 135;
            this.p5_s5CheckBox.Text = "Sin la música, mi vida sería más triste.";
            this.p5_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p6_s5CheckBox
            // 
            this.p6_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p6_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p6_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p6_s5", true));
            this.p6_s5CheckBox.Location = new System.Drawing.Point(526, 426);
            this.p6_s5CheckBox.Name = "p6_s5CheckBox";
            this.p6_s5CheckBox.Size = new System.Drawing.Size(330, 32);
            this.p6_s5CheckBox.TabIndex = 136;
            this.p6_s5CheckBox.Text = "En ocasiones me sorprendo cantando mentalmente la música del anuncio de televisió" +
    "n o alguna otra melodía.";
            this.p6_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p7_s5CheckBox
            // 
            this.p7_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p7_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p7_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p7_s5", true));
            this.p7_s5CheckBox.Location = new System.Drawing.Point(526, 478);
            this.p7_s5CheckBox.Name = "p7_s5CheckBox";
            this.p7_s5CheckBox.Size = new System.Drawing.Size(330, 30);
            this.p7_s5CheckBox.TabIndex = 137;
            this.p7_s5CheckBox.Text = "Puedo seguir fácilmente el ritmo del tema musical con un instrumento de percusión" +
    ".";
            this.p7_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p8_s5CheckBox
            // 
            this.p8_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p8_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p8_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p8_s5", true));
            this.p8_s5CheckBox.Location = new System.Drawing.Point(526, 526);
            this.p8_s5CheckBox.Name = "p8_s5CheckBox";
            this.p8_s5CheckBox.Size = new System.Drawing.Size(330, 30);
            this.p8_s5CheckBox.TabIndex = 138;
            this.p8_s5CheckBox.Text = "Conozco las melodías de numerosas canciones son piezas musicales.";
            this.p8_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p9_s5CheckBox
            // 
            this.p9_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p9_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p9_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p9_s5", true));
            this.p9_s5CheckBox.Location = new System.Drawing.Point(526, 572);
            this.p9_s5CheckBox.Name = "p9_s5CheckBox";
            this.p9_s5CheckBox.Size = new System.Drawing.Size(330, 36);
            this.p9_s5CheckBox.TabIndex = 139;
            this.p9_s5CheckBox.Text = "Con sólo escuchar una selección musical con una o dos meses, ya soy capaz de repr" +
    "oducir la con bastante acierto.";
            this.p9_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p10_s5CheckBox
            // 
            this.p10_s5CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p10_s5CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p10_s5CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p10_s5", true));
            this.p10_s5CheckBox.Location = new System.Drawing.Point(526, 618);
            this.p10_s5CheckBox.Name = "p10_s5CheckBox";
            this.p10_s5CheckBox.Size = new System.Drawing.Size(330, 32);
            this.p10_s5CheckBox.TabIndex = 140;
            this.p10_s5CheckBox.Text = "Acostumbro a producir sonidos rítmicos con golpecitos o a cantar melodías mientra" +
    "s estoy trabajando o estudiando.";
            this.p10_s5CheckBox.UseVisualStyleBackColor = false;
            // 
            // p1_s6CheckBox
            // 
            this.p1_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p1_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p1_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p1_s6", true));
            this.p1_s6CheckBox.Location = new System.Drawing.Point(971, 193);
            this.p1_s6CheckBox.Name = "p1_s6CheckBox";
            this.p1_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p1_s6CheckBox.TabIndex = 141;
            this.p1_s6CheckBox.Text = "Soy del tipo de personas a las que los demás piden opinión y consejo en el trabaj" +
    "o o en el vecindario.";
            this.p1_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // p2_s6CheckBox
            // 
            this.p2_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p2_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p2_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p2_s6", true));
            this.p2_s6CheckBox.Location = new System.Drawing.Point(971, 234);
            this.p2_s6CheckBox.Name = "p2_s6CheckBox";
            this.p2_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p2_s6CheckBox.TabIndex = 142;
            this.p2_s6CheckBox.Text = "Prefiero los deportes de equipo (fútbol o baloncesto) a los deportes solitarios (" +
    "natación o el jogging).";
            this.p2_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // p3_s6CheckBox
            // 
            this.p3_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p3_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p3_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p3_s6", true));
            this.p3_s6CheckBox.Location = new System.Drawing.Point(971, 277);
            this.p3_s6CheckBox.Name = "p3_s6CheckBox";
            this.p3_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p3_s6CheckBox.TabIndex = 143;
            this.p3_s6CheckBox.Text = "Cuando tengo un problema, tiendo a buscar la ayuda de otra persona en lugar de in" +
    "tentar resolverlo por mí mismo.";
            this.p3_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // p4_s6CheckBox
            // 
            this.p4_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p4_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p4_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p4_s6", true));
            this.p4_s6CheckBox.Location = new System.Drawing.Point(971, 318);
            this.p4_s6CheckBox.Name = "p4_s6CheckBox";
            this.p4_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p4_s6CheckBox.TabIndex = 144;
            this.p4_s6CheckBox.Text = "Tengo al menos tres amigos íntimos.";
            this.p4_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // p5_s6CheckBox
            // 
            this.p5_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p5_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p5_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p5_s6", true));
            this.p5_s6CheckBox.Location = new System.Drawing.Point(971, 358);
            this.p5_s6CheckBox.Name = "p5_s6CheckBox";
            this.p5_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p5_s6CheckBox.TabIndex = 145;
            this.p5_s6CheckBox.Text = "Me gustan más los juegos sociales (como el Monopoly) que los juegos en solitario " +
    "(videojuegos).";
            this.p5_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // p6_s6CheckBox
            // 
            this.p6_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p6_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p6_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p6_s6", true));
            this.p6_s6CheckBox.Location = new System.Drawing.Point(971, 400);
            this.p6_s6CheckBox.Name = "p6_s6CheckBox";
            this.p6_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p6_s6CheckBox.TabIndex = 146;
            this.p6_s6CheckBox.Text = "Disfruto con el reto que supone enseñar a otra persona, o grupos de personas, lo " +
    "que sé hacer.";
            this.p6_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // p7_s6CheckBox
            // 
            this.p7_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p7_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p7_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p7_s6", true));
            this.p7_s6CheckBox.Location = new System.Drawing.Point(971, 440);
            this.p7_s6CheckBox.Name = "p7_s6CheckBox";
            this.p7_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p7_s6CheckBox.TabIndex = 147;
            this.p7_s6CheckBox.Text = "Me considero un líder (o los demás me dicen que lo soy).";
            this.p7_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // p8_s6CheckBox
            // 
            this.p8_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p8_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p8_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p8_s6", true));
            this.p8_s6CheckBox.Location = new System.Drawing.Point(971, 478);
            this.p8_s6CheckBox.Name = "p8_s6CheckBox";
            this.p8_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p8_s6CheckBox.TabIndex = 148;
            this.p8_s6CheckBox.Text = "Me siento cómodo entre una multitud.";
            this.p8_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // p9_s6CheckBox
            // 
            this.p9_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p9_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p9_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p9_s6", true));
            this.p9_s6CheckBox.Location = new System.Drawing.Point(971, 514);
            this.p9_s6CheckBox.Name = "p9_s6CheckBox";
            this.p9_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p9_s6CheckBox.TabIndex = 149;
            this.p9_s6CheckBox.Text = "Me gusta participar en actividades sociales relacionadas con mi trabajo, con la p" +
    "arroquia o con la comunidad.";
            this.p9_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // p10_s6CheckBox
            // 
            this.p10_s6CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p10_s6CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p10_s6CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p10_s6", true));
            this.p10_s6CheckBox.Location = new System.Drawing.Point(971, 556);
            this.p10_s6CheckBox.Name = "p10_s6CheckBox";
            this.p10_s6CheckBox.Size = new System.Drawing.Size(304, 30);
            this.p10_s6CheckBox.TabIndex = 150;
            this.p10_s6CheckBox.Text = "Prefiero pasar una tarde en una fiesta animada que solo en casa.";
            this.p10_s6CheckBox.UseVisualStyleBackColor = false;
            // 
            // matriculaTextBox
            // 
            this.matriculaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource, "matricula", true));
            this.matriculaTextBox.Location = new System.Drawing.Point(359, 83);
            this.matriculaTextBox.Name = "matriculaTextBox";
            this.matriculaTextBox.Size = new System.Drawing.Size(100, 20);
            this.matriculaTextBox.TabIndex = 151;
            // 
            // correoComboBox
            // 
            this.correoComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource, "correo", true));
            this.correoComboBox.FormattingEnabled = true;
            this.correoComboBox.Location = new System.Drawing.Point(210, 82);
            this.correoComboBox.Name = "correoComboBox";
            this.correoComboBox.Size = new System.Drawing.Size(121, 21);
            this.correoComboBox.TabIndex = 152;
            // 
            // testexamenDataGridView
            // 
            this.testexamenDataGridView.AutoGenerateColumns = false;
            this.testexamenDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.testexamenDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4});
            this.testexamenDataGridView.DataSource = this.testexamenBindingSource;
            this.testexamenDataGridView.Location = new System.Drawing.Point(381, 168);
            this.testexamenDataGridView.Name = "testexamenDataGridView";
            this.testexamenDataGridView.Size = new System.Drawing.Size(139, 220);
            this.testexamenDataGridView.TabIndex = 152;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "correo";
            this.dataGridViewTextBoxColumn4.HeaderText = "correo";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Modifica2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.testexamenDataGridView);
            this.Controls.Add(this.correoComboBox);
            this.Controls.Add(this.matriculaTextBox);
            this.Controls.Add(this.p10_s6CheckBox);
            this.Controls.Add(this.p9_s6CheckBox);
            this.Controls.Add(this.p8_s6CheckBox);
            this.Controls.Add(this.p7_s6CheckBox);
            this.Controls.Add(this.p6_s6CheckBox);
            this.Controls.Add(this.p5_s6CheckBox);
            this.Controls.Add(this.p4_s6CheckBox);
            this.Controls.Add(this.p3_s6CheckBox);
            this.Controls.Add(this.p2_s6CheckBox);
            this.Controls.Add(this.p1_s6CheckBox);
            this.Controls.Add(this.p10_s5CheckBox);
            this.Controls.Add(this.p9_s5CheckBox);
            this.Controls.Add(this.p8_s5CheckBox);
            this.Controls.Add(this.p7_s5CheckBox);
            this.Controls.Add(this.p6_s5CheckBox);
            this.Controls.Add(this.p5_s5CheckBox);
            this.Controls.Add(this.p4_s5CheckBox);
            this.Controls.Add(this.p3_s5CheckBox);
            this.Controls.Add(this.p1_s5CheckBox);
            this.Controls.Add(this.p2_s5CheckBox);
            this.Controls.Add(this.p10_s4CheckBox);
            this.Controls.Add(this.p9_s4CheckBox);
            this.Controls.Add(this.p8_s4CheckBox);
            this.Controls.Add(this.p7_s4CheckBox);
            this.Controls.Add(this.p6_s4CheckBox);
            this.Controls.Add(this.p5_s4CheckBox);
            this.Controls.Add(this.p4_s4CheckBox);
            this.Controls.Add(this.p3_s4CheckBox);
            this.Controls.Add(this.p2_s4CheckBox);
            this.Controls.Add(this.p1_s4CheckBox);
            this.Controls.Add(this.materialRaisedButton1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Name = "Modifica2";
            this.Text = "Modifica2";
            this.Load += new System.EventHandler(this.Modifica2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
        private System.Windows.Forms.CheckBox p1_s4CheckBox;
        private System.Windows.Forms.CheckBox p2_s4CheckBox;
        private System.Windows.Forms.CheckBox p3_s4CheckBox;
        private System.Windows.Forms.CheckBox p4_s4CheckBox;
        private System.Windows.Forms.CheckBox p5_s4CheckBox;
        private System.Windows.Forms.CheckBox p6_s4CheckBox;
        private System.Windows.Forms.CheckBox p7_s4CheckBox;
        private System.Windows.Forms.CheckBox p8_s4CheckBox;
        private System.Windows.Forms.CheckBox p9_s4CheckBox;
        private System.Windows.Forms.CheckBox p10_s4CheckBox;
        private System.Windows.Forms.CheckBox p2_s5CheckBox;
        private System.Windows.Forms.CheckBox p1_s5CheckBox;
        private System.Windows.Forms.CheckBox p3_s5CheckBox;
        private System.Windows.Forms.CheckBox p4_s5CheckBox;
        private System.Windows.Forms.CheckBox p5_s5CheckBox;
        private System.Windows.Forms.CheckBox p6_s5CheckBox;
        private System.Windows.Forms.CheckBox p7_s5CheckBox;
        private System.Windows.Forms.CheckBox p8_s5CheckBox;
        private System.Windows.Forms.CheckBox p9_s5CheckBox;
        private System.Windows.Forms.CheckBox p10_s5CheckBox;
        private System.Windows.Forms.CheckBox p1_s6CheckBox;
        private System.Windows.Forms.CheckBox p2_s6CheckBox;
        private System.Windows.Forms.CheckBox p3_s6CheckBox;
        private System.Windows.Forms.CheckBox p4_s6CheckBox;
        private System.Windows.Forms.CheckBox p5_s6CheckBox;
        private System.Windows.Forms.CheckBox p6_s6CheckBox;
        private System.Windows.Forms.CheckBox p7_s6CheckBox;
        private System.Windows.Forms.CheckBox p8_s6CheckBox;
        private System.Windows.Forms.CheckBox p9_s6CheckBox;
        private System.Windows.Forms.CheckBox p10_s6CheckBox;
        public datosTableAdapters.TableAdapterManager tableAdapterManager;
        public datos datos;
        public System.Windows.Forms.BindingSource testexamenBindingSource;
        public datosTableAdapters.testexamenTableAdapter testexamenTableAdapter;
        private System.Windows.Forms.TextBox matriculaTextBox;
        private System.Windows.Forms.ComboBox correoComboBox;
        private System.Windows.Forms.DataGridView testexamenDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}