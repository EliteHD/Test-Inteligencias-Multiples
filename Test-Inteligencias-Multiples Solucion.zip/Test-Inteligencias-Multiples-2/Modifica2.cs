﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Modifica2 : MaterialSkin.Controls.MaterialForm
    {
        int resultados4;
        int resultados5;
        int resultados6;


        public Modifica2(int resultados1,int resultados2, int resultados3,string matricula)
        {
            InitializeComponent();
            this.resultados1 = resultados1;
            this.resultados2 = resultados2;
            this.matricula = matricula;
            this.resultados3 = resultados3;

        }
        int resultados1, resultados2, resultados3;
        string matricula;

        private void Modifica2_Load(object sender, EventArgs e)
        {
            
            // TODO: esta línea de código carga datos en la tabla 'datos.testexamen' Puede moverla o quitarla según sea necesario.
            this.testexamenTableAdapter.Fill(this.datos.testexamen);
            correoComboBox.Enabled = false;
            matriculaTextBox.Enabled = false;
            matriculaTextBox.Text = matricula;

        }

        private void materialLabel1_Click(object sender, EventArgs e)
        {
            Modifica1 m1 = new Modifica1();
            m1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Modifica1 m1 = new Modifica1();
            m1.Show();
            this.Hide();
        }

        private void correoComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void testexamenDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
                    }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {

            if (p1_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }
            if (p2_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }
            if (p3_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }
            if (p4_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }
            if (p5_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }
            if (p6_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }
            if (p7_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }
            if (p8_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }
            if (p9_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }
            if (p10_s4CheckBox.Checked == true)
            {
                resultados4 += 1;
            }



            if (p1_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }
            if (p2_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }
            if (p3_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }
            if (p4_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }
            if (p5_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }
            if (p6_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }
            if (p7_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }
            if (p8_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }
            if (p9_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }
            if (p10_s5CheckBox.Checked == true)
            {
                resultados5 += 1;
            }



            if (p1_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }
            if (p2_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }
            if (p3_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }
            if (p4_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }
            if (p5_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }
            if (p6_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }
            if (p7_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }
            if (p8_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }
            if (p9_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }
            if (p10_s6CheckBox.Checked == true)
            {
                resultados6 += 1;
            }


            Seccion4 s4 = new Seccion4();
            s4.Matricula = Convert.ToInt32(matriculaTextBox.Text);
            s4.p1_s4 = p1_s4CheckBox.Checked;
            s4.p2_s4 = p2_s4CheckBox.Checked;
            s4.p3_s4 = p3_s4CheckBox.Checked;
            s4.p4_s4 = p4_s4CheckBox.Checked;
            s4.p5_s4 = p5_s4CheckBox.Checked;
            s4.p6_s4 = p6_s4CheckBox.Checked;
            s4.p7_s4 = p7_s4CheckBox.Checked;
            s4.p8_s4 = p8_s4CheckBox.Checked;
            s4.p9_s4 = p9_s4CheckBox.Checked;
            s4.p10_s4 = p10_s4CheckBox.Checked;

            Seccion5 s5 = new Seccion5();
            s5.Matricula = Convert.ToInt32(matriculaTextBox.Text);
            s5.p1_s5 = p1_s5CheckBox.Checked;
            s5.p2_s5 = p2_s5CheckBox.Checked;
            s5.p3_s5 = p3_s5CheckBox.Checked;
            s5.p4_s5 = p4_s5CheckBox.Checked;
            s5.p5_s5 = p5_s5CheckBox.Checked;
            s5.p6_s5 = p6_s5CheckBox.Checked;
            s5.p7_s5 = p7_s5CheckBox.Checked;
            s5.p8_s5 = p8_s5CheckBox.Checked;
            s5.p9_s5 = p9_s5CheckBox.Checked;
            s5.p10_s5 = p10_s5CheckBox.Checked;

            Seccion6 s6 = new Seccion6();
            s6.Matricula = Convert.ToInt32(matriculaTextBox.Text);
            s6.p1_s6 = p1_s6CheckBox.Checked;
            s6.p2_s6 = p2_s6CheckBox.Checked;
            s6.p3_s6 = p3_s6CheckBox.Checked;
            s6.p4_s6 = p4_s6CheckBox.Checked;
            s6.p5_s6 = p5_s6CheckBox.Checked;
            s6.p6_s6 = p6_s6CheckBox.Checked;
            s6.p7_s6 = p7_s6CheckBox.Checked;
            s6.p8_s6 = p8_s6CheckBox.Checked;
            s6.p9_s6 = p9_s6CheckBox.Checked;
            s6.p10_s6 = p10_s6CheckBox.Checked;


            int resultado = EncuestadoDAO.Seccion4(s4);
            int resultado2 = EncuestadoDAO.Seccion5(s5);
            int resultado3 = EncuestadoDAO.Seccion6(s6);
           




            Modifica3 m3 = new Modifica3(resultados1, resultados2, resultados3, resultados4, resultados5, resultados6);
            m3.Show();
            this.Hide();

        }

        private void testexamenBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.testexamenBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.datos);

        }
    }
}
