﻿namespace Test_Inteligencias_Multiples_2
{
    partial class Modifica3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.datos = new Test_Inteligencias_Multiples_2.datos();
            this.testexamenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testexamenTableAdapter = new Test_Inteligencias_Multiples_2.datosTableAdapters.testexamenTableAdapter();
            this.tableAdapterManager = new Test_Inteligencias_Multiples_2.datosTableAdapters.TableAdapterManager();
            this.p1_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p2_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p3_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p4_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p5_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p6_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p7_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p8_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p9_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p10_s7CheckBox = new System.Windows.Forms.CheckBox();
            this.p1_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.p2_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.p3_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.p4_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.p5_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.p6_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.p7_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.p8_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.p9_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.p10_s8CheckBox = new System.Windows.Forms.CheckBox();
            this.nombreTextBox = new System.Windows.Forms.TextBox();
            this.matriculaTextBox = new System.Windows.Forms.TextBox();
            this.correoComboBox = new System.Windows.Forms.ComboBox();
            this.testexamenDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.datos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(257, 635);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(444, 57);
            this.materialRaisedButton1.TabIndex = 156;
            this.materialRaisedButton1.Text = "ACTUALIZAR RESPUESTAS";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(599, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 25);
            this.label1.TabIndex = 132;
            this.label1.Text = "Inteligencia naturalista";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(536, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(324, 25);
            this.label3.TabIndex = 133;
            this.label3.Text = "________________________";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(74, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(278, 25);
            this.label2.TabIndex = 120;
            this.label2.Text = "Inteligencia intrapersonal";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(71, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(324, 25);
            this.label11.TabIndex = 121;
            this.label11.Text = "________________________";
            // 
            // datos
            // 
            this.datos.DataSetName = "datos";
            this.datos.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // testexamenBindingSource
            // 
            this.testexamenBindingSource.DataMember = "testexamen";
            this.testexamenBindingSource.DataSource = this.datos;
            // 
            // testexamenTableAdapter
            // 
            this.testexamenTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.testexamenTableAdapter = this.testexamenTableAdapter;
            this.tableAdapterManager.UpdateOrder = Test_Inteligencias_Multiples_2.datosTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // p1_s7CheckBox
            // 
            this.p1_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p1_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p1_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p1_s7", true));
            this.p1_s7CheckBox.Location = new System.Drawing.Point(76, 133);
            this.p1_s7CheckBox.Name = "p1_s7CheckBox";
            this.p1_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p1_s7CheckBox.TabIndex = 158;
            this.p1_s7CheckBox.Text = "Habitualmente dedico tiempo a meditar, reflexionar o pensar en cuestiones importa" +
    "ntes de la vida.";
            this.p1_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p2_s7CheckBox
            // 
            this.p2_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p2_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p2_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p2_s7", true));
            this.p2_s7CheckBox.Location = new System.Drawing.Point(76, 178);
            this.p2_s7CheckBox.Name = "p2_s7CheckBox";
            this.p2_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p2_s7CheckBox.TabIndex = 159;
            this.p2_s7CheckBox.Text = "He asistido a sesiones de asesoramiento o a seminarios de crecimiento personal pa" +
    "ra aprender a conocerme más.";
            this.p2_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p3_s7CheckBox
            // 
            this.p3_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p3_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p3_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p3_s7", true));
            this.p3_s7CheckBox.Location = new System.Drawing.Point(76, 224);
            this.p3_s7CheckBox.Name = "p3_s7CheckBox";
            this.p3_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p3_s7CheckBox.TabIndex = 160;
            this.p3_s7CheckBox.Text = "Soy capaz de afrontar los contratiempos con fuerza moral.";
            this.p3_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p4_s7CheckBox
            // 
            this.p4_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p4_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p4_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p4_s7", true));
            this.p4_s7CheckBox.Location = new System.Drawing.Point(76, 268);
            this.p4_s7CheckBox.Name = "p4_s7CheckBox";
            this.p4_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p4_s7CheckBox.TabIndex = 161;
            this.p4_s7CheckBox.Text = "Tengo una afición especial o una actividad que guardo para mí.";
            this.p4_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p5_s7CheckBox
            // 
            this.p5_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p5_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p5_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p5_s7", true));
            this.p5_s7CheckBox.Location = new System.Drawing.Point(76, 312);
            this.p5_s7CheckBox.Name = "p5_s7CheckBox";
            this.p5_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p5_s7CheckBox.TabIndex = 162;
            this.p5_s7CheckBox.Text = "Tengo algunos objetivos vitales importantes en los que pienso de forma habitual.";
            this.p5_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p6_s7CheckBox
            // 
            this.p6_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p6_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p6_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p6_s7", true));
            this.p6_s7CheckBox.Location = new System.Drawing.Point(76, 356);
            this.p6_s7CheckBox.Name = "p6_s7CheckBox";
            this.p6_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p6_s7CheckBox.TabIndex = 163;
            this.p6_s7CheckBox.Text = "Mantengo una visión realista de mis puntos fuertes y débiles (confirmados mediant" +
    "e feedback de otras fuentes).";
            this.p6_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p7_s7CheckBox
            // 
            this.p7_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p7_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p7_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p7_s7", true));
            this.p7_s7CheckBox.Location = new System.Drawing.Point(76, 400);
            this.p7_s7CheckBox.Name = "p7_s7CheckBox";
            this.p7_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p7_s7CheckBox.TabIndex = 164;
            this.p7_s7CheckBox.Text = "Preferiría pasar un fin de semana solo en una cabaña, en el bosque, que en un lug" +
    "ar turístico de lujo lleno de gente.";
            this.p7_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p8_s7CheckBox
            // 
            this.p8_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p8_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p8_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p8_s7", true));
            this.p8_s7CheckBox.Location = new System.Drawing.Point(76, 446);
            this.p8_s7CheckBox.Name = "p8_s7CheckBox";
            this.p8_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p8_s7CheckBox.TabIndex = 165;
            this.p8_s7CheckBox.Text = "Me considero una persona con mucha fuerza de voluntad o independiente.";
            this.p8_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p9_s7CheckBox
            // 
            this.p9_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p9_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p9_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p9_s7", true));
            this.p9_s7CheckBox.Location = new System.Drawing.Point(76, 492);
            this.p9_s7CheckBox.Name = "p9_s7CheckBox";
            this.p9_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p9_s7CheckBox.TabIndex = 166;
            this.p9_s7CheckBox.Text = "Escribo un diario personal en el que recojo los pensamientos relacionados con mi " +
    "vida interior.";
            this.p9_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p10_s7CheckBox
            // 
            this.p10_s7CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p10_s7CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p10_s7CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p10_s7", true));
            this.p10_s7CheckBox.Location = new System.Drawing.Point(76, 538);
            this.p10_s7CheckBox.Name = "p10_s7CheckBox";
            this.p10_s7CheckBox.Size = new System.Drawing.Size(319, 39);
            this.p10_s7CheckBox.TabIndex = 167;
            this.p10_s7CheckBox.Text = "Soy trabajador autónomo o he pensado muy seriamente en la posibilidad de poner en" +
    " marcha mi propio negocio.";
            this.p10_s7CheckBox.UseVisualStyleBackColor = false;
            // 
            // p1_s8CheckBox
            // 
            this.p1_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p1_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p1_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p1_s8", true));
            this.p1_s8CheckBox.Location = new System.Drawing.Point(541, 116);
            this.p1_s8CheckBox.Name = "p1_s8CheckBox";
            this.p1_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p1_s8CheckBox.TabIndex = 168;
            this.p1_s8CheckBox.Text = "Me gusta ir de excursión, el senderismo o simplemente pasear en plena naturaleza." +
    "";
            this.p1_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // p2_s8CheckBox
            // 
            this.p2_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p2_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p2_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p2_s8", true));
            this.p2_s8CheckBox.Location = new System.Drawing.Point(541, 161);
            this.p2_s8CheckBox.Name = "p2_s8CheckBox";
            this.p2_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p2_s8CheckBox.TabIndex = 169;
            this.p2_s8CheckBox.Text = "Pertenezco a una asociación de voluntarios relacionada con la conservación del Me" +
    "dioambiente.";
            this.p2_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // p3_s8CheckBox
            // 
            this.p3_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p3_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p3_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p3_s8", true));
            this.p3_s8CheckBox.Location = new System.Drawing.Point(541, 207);
            this.p3_s8CheckBox.Name = "p3_s8CheckBox";
            this.p3_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p3_s8CheckBox.TabIndex = 170;
            this.p3_s8CheckBox.Text = "Me encanta tener animales en casa.";
            this.p3_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // p4_s8CheckBox
            // 
            this.p4_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p4_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p4_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p4_s8", true));
            this.p4_s8CheckBox.Location = new System.Drawing.Point(541, 251);
            this.p4_s8CheckBox.Name = "p4_s8CheckBox";
            this.p4_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p4_s8CheckBox.TabIndex = 171;
            this.p4_s8CheckBox.Text = "Tengo una afición relacionada de algún modo con la naturaleza (por ejemplo, la ob" +
    "servación de aves).";
            this.p4_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // p5_s8CheckBox
            // 
            this.p5_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p5_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p5_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p5_s8", true));
            this.p5_s8CheckBox.Location = new System.Drawing.Point(541, 295);
            this.p5_s8CheckBox.Name = "p5_s8CheckBox";
            this.p5_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p5_s8CheckBox.TabIndex = 172;
            this.p5_s8CheckBox.Text = "He asistido a cursos relacionados con la naturaleza (por ejemplo, botánica o zool" +
    "ogía).";
            this.p5_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // p6_s8CheckBox
            // 
            this.p6_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p6_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p6_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p6_s8", true));
            this.p6_s8CheckBox.Location = new System.Drawing.Point(541, 339);
            this.p6_s8CheckBox.Name = "p6_s8CheckBox";
            this.p6_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p6_s8CheckBox.TabIndex = 173;
            this.p6_s8CheckBox.Text = "Se me da bien describir diferencias entre distintos tipos de árboles, perros, páj" +
    "aros u otras especies de flora o fauna.";
            this.p6_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // p7_s8CheckBox
            // 
            this.p7_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p7_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p7_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p7_s8", true));
            this.p7_s8CheckBox.Location = new System.Drawing.Point(541, 383);
            this.p7_s8CheckBox.Name = "p7_s8CheckBox";
            this.p7_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p7_s8CheckBox.TabIndex = 174;
            this.p7_s8CheckBox.Text = "Me gusta leer libros o revistas, o ver programas de televisión o películas, en lo" +
    "s que la naturaleza esté presente.";
            this.p7_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // p8_s8CheckBox
            // 
            this.p8_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p8_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p8_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p8_s8", true));
            this.p8_s8CheckBox.Location = new System.Drawing.Point(541, 429);
            this.p8_s8CheckBox.Name = "p8_s8CheckBox";
            this.p8_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p8_s8CheckBox.TabIndex = 175;
            this.p8_s8CheckBox.Text = "Cuando tengo vacaciones, prefiero los entornos naturales (parques, senderismo) a " +
    "los hoteles y destinos urbanos.";
            this.p8_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // p9_s8CheckBox
            // 
            this.p9_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p9_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p9_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p9_s8", true));
            this.p9_s8CheckBox.Location = new System.Drawing.Point(541, 475);
            this.p9_s8CheckBox.Name = "p9_s8CheckBox";
            this.p9_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p9_s8CheckBox.TabIndex = 176;
            this.p9_s8CheckBox.Text = "Me encanta visitar zoológicos, acuarios y demás lugares donde se estudia el mundo" +
    " natural.";
            this.p9_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // p10_s8CheckBox
            // 
            this.p10_s8CheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.p10_s8CheckBox.BackColor = System.Drawing.Color.Transparent;
            this.p10_s8CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.testexamenBindingSource, "p10_s8", true));
            this.p10_s8CheckBox.Location = new System.Drawing.Point(541, 521);
            this.p10_s8CheckBox.Name = "p10_s8CheckBox";
            this.p10_s8CheckBox.Size = new System.Drawing.Size(325, 41);
            this.p10_s8CheckBox.TabIndex = 177;
            this.p10_s8CheckBox.Text = "Tengo un jardín y disfrutó cuidándolo.";
            this.p10_s8CheckBox.UseVisualStyleBackColor = false;
            // 
            // nombreTextBox
            // 
            this.nombreTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource, "nombre", true));
            this.nombreTextBox.Location = new System.Drawing.Point(401, 178);
            this.nombreTextBox.Name = "nombreTextBox";
            this.nombreTextBox.Size = new System.Drawing.Size(100, 20);
            this.nombreTextBox.TabIndex = 178;
            // 
            // matriculaTextBox
            // 
            this.matriculaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource, "matricula", true));
            this.matriculaTextBox.Location = new System.Drawing.Point(401, 197);
            this.matriculaTextBox.Name = "matriculaTextBox";
            this.matriculaTextBox.Size = new System.Drawing.Size(100, 20);
            this.matriculaTextBox.TabIndex = 179;
            // 
            // correoComboBox
            // 
            this.correoComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource, "correo", true));
            this.correoComboBox.FormattingEnabled = true;
            this.correoComboBox.Location = new System.Drawing.Point(401, 223);
            this.correoComboBox.Name = "correoComboBox";
            this.correoComboBox.Size = new System.Drawing.Size(121, 21);
            this.correoComboBox.TabIndex = 180;
            // 
            // testexamenDataGridView
            // 
            this.testexamenDataGridView.AutoGenerateColumns = false;
            this.testexamenDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.testexamenDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4});
            this.testexamenDataGridView.DataSource = this.testexamenBindingSource;
            this.testexamenDataGridView.Location = new System.Drawing.Point(400, 116);
            this.testexamenDataGridView.Name = "testexamenDataGridView";
            this.testexamenDataGridView.Size = new System.Drawing.Size(134, 220);
            this.testexamenDataGridView.TabIndex = 180;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "correo";
            this.dataGridViewTextBoxColumn4.HeaderText = "correo";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Modifica3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 725);
            this.Controls.Add(this.testexamenDataGridView);
            this.Controls.Add(this.correoComboBox);
            this.Controls.Add(this.matriculaTextBox);
            this.Controls.Add(this.nombreTextBox);
            this.Controls.Add(this.p10_s8CheckBox);
            this.Controls.Add(this.p9_s8CheckBox);
            this.Controls.Add(this.p8_s8CheckBox);
            this.Controls.Add(this.p7_s8CheckBox);
            this.Controls.Add(this.p6_s8CheckBox);
            this.Controls.Add(this.p5_s8CheckBox);
            this.Controls.Add(this.p4_s8CheckBox);
            this.Controls.Add(this.p3_s8CheckBox);
            this.Controls.Add(this.p2_s8CheckBox);
            this.Controls.Add(this.p1_s8CheckBox);
            this.Controls.Add(this.p10_s7CheckBox);
            this.Controls.Add(this.p9_s7CheckBox);
            this.Controls.Add(this.p8_s7CheckBox);
            this.Controls.Add(this.p7_s7CheckBox);
            this.Controls.Add(this.p6_s7CheckBox);
            this.Controls.Add(this.p5_s7CheckBox);
            this.Controls.Add(this.p4_s7CheckBox);
            this.Controls.Add(this.p3_s7CheckBox);
            this.Controls.Add(this.p2_s7CheckBox);
            this.Controls.Add(this.p1_s7CheckBox);
            this.Controls.Add(this.materialRaisedButton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Name = "Modifica3";
            this.Text = "Modifica3";
            this.Load += new System.EventHandler(this.Modifica3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox p1_s7CheckBox;
        private System.Windows.Forms.CheckBox p2_s7CheckBox;
        private System.Windows.Forms.CheckBox p3_s7CheckBox;
        private System.Windows.Forms.CheckBox p4_s7CheckBox;
        private System.Windows.Forms.CheckBox p5_s7CheckBox;
        private System.Windows.Forms.CheckBox p6_s7CheckBox;
        private System.Windows.Forms.CheckBox p7_s7CheckBox;
        private System.Windows.Forms.CheckBox p8_s7CheckBox;
        private System.Windows.Forms.CheckBox p9_s7CheckBox;
        private System.Windows.Forms.CheckBox p10_s7CheckBox;
        private System.Windows.Forms.CheckBox p1_s8CheckBox;
        private System.Windows.Forms.CheckBox p2_s8CheckBox;
        private System.Windows.Forms.CheckBox p3_s8CheckBox;
        private System.Windows.Forms.CheckBox p4_s8CheckBox;
        private System.Windows.Forms.CheckBox p5_s8CheckBox;
        private System.Windows.Forms.CheckBox p6_s8CheckBox;
        private System.Windows.Forms.CheckBox p7_s8CheckBox;
        private System.Windows.Forms.CheckBox p8_s8CheckBox;
        private System.Windows.Forms.CheckBox p9_s8CheckBox;
        private System.Windows.Forms.CheckBox p10_s8CheckBox;
        private System.Windows.Forms.TextBox nombreTextBox;
        private System.Windows.Forms.TextBox matriculaTextBox;
        private System.Windows.Forms.ComboBox correoComboBox;
        public datos datos;
        public System.Windows.Forms.BindingSource testexamenBindingSource;
        public datosTableAdapters.testexamenTableAdapter testexamenTableAdapter;
        public datosTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView testexamenDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}