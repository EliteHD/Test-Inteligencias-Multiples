﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Modifica3 : MaterialSkin.Controls.MaterialForm
    {
        int resultados7;
        int resultados8;


        public Modifica3(int resultados1,int resultados2, int resultados3, int resultados4, int resultados5, int resultados6)
        {
            InitializeComponent();
            this.resultados1 = resultados1;
            this.resultados2 = resultados2;
            this.resultados3 = resultados3;
            this.resultados4 = resultados4;
            this.resultados5 = resultados5;
            this.resultados6 = resultados6;

        }
        int resultados1, resultados2, resultados3, resultados4, resultados5, resultados6;

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void Modifica3_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'datos.testexamen' Puede moverla o quitarla según sea necesario.
            this.testexamenTableAdapter.Fill(this.datos.testexamen);
            correoComboBox.Enabled = false;
            matriculaTextBox.Enabled = false;
        }

        private void testexamenBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.testexamenBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.datos);

        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            if (p1_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }
            if (p2_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }
            if (p3_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }
            if (p4_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }
            if (p5_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }
            if (p6_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }
            if (p7_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }
            if (p8_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }
            if (p9_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }
            if (p10_s7CheckBox.Checked == true)
            {
                resultados7 += 1;
            }



            if (p1_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }
            if (p2_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }
            if (p3_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }
            if (p4_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }
            if (p5_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }
            if (p6_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }
            if (p7_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }
            if (p8_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }
            if (p9_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }
            if (p10_s8CheckBox.Checked == true)
            {
                resultados8 += 1;
            }


            Seccion7 s7 = new Seccion7();
            s7.Matricula = Convert.ToInt32(matriculaTextBox.Text);
            s7.p1_s7 = p1_s7CheckBox.Checked;
            s7.p2_s7 = p2_s7CheckBox.Checked;
            s7.p3_s7 = p3_s7CheckBox.Checked;
            s7.p4_s7 = p4_s7CheckBox.Checked;
            s7.p5_s7 = p5_s7CheckBox.Checked;
            s7.p6_s7 = p6_s7CheckBox.Checked;
            s7.p7_s7 = p7_s7CheckBox.Checked;
            s7.p8_s7 = p8_s7CheckBox.Checked;
            s7.p9_s7 = p9_s7CheckBox.Checked;
            s7.p10_s7 = p10_s7CheckBox.Checked;

            Seccion8 s8 = new Seccion8();
            s8.Matricula = Convert.ToInt32(matriculaTextBox.Text);
            s8.p1_s8 = p1_s8CheckBox.Checked;
            s8.p2_s8 = p2_s8CheckBox.Checked;
            s8.p3_s8 = p3_s8CheckBox.Checked;
            s8.p4_s8 = p4_s8CheckBox.Checked;
            s8.p5_s8 = p5_s8CheckBox.Checked;
            s8.p6_s8 = p6_s8CheckBox.Checked;
            s8.p7_s8 = p7_s8CheckBox.Checked;
            s8.p8_s8 = p8_s8CheckBox.Checked;
            s8.p9_s8 = p9_s8CheckBox.Checked;
            s8.p10_s8 = p10_s8CheckBox.Checked;



            int resultado = EncuestadoDAO.Seccion7(s7);
            int resultado1 = EncuestadoDAO.Seccion8(s8);
            if (resultado > 0 && resultado1>0)
            {
                MessageBox.Show("Tus respuestas fueron modificadas, Checa la grafica en caso de tener multiples Inteligencias, Gracias!", "Avance", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }

            ResultadoModificado rtmod = new ResultadoModificado(resultados1,resultados2, resultados3, resultados4, resultados5, resultados6, resultados7, resultados8);
            rtmod.Show();
            this.Hide();

        }
    }
}
