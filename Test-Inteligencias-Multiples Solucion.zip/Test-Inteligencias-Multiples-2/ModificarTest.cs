﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class ModificarTest : MaterialSkin.Controls.MaterialForm
    {
        public ModificarTest()
        {
            InitializeComponent();
        }

        private void ModificarTest_Load(object sender, EventArgs e)
        {
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
           

        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
           
        }

        private void ModificarTest_Load_1(object sender, EventArgs e)
        {

        }
    }
}
