﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Inteligencias_Multiples_2
{
    public partial class Registro : MaterialSkin.Controls.MaterialForm
    {
        DateTime fechahoy = DateTime.Now;
        
        public Registro()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtfecha.Text = fechahoy.ToShortDateString();
            txthora.Text = fechahoy.ToShortTimeString();
            txtfecha.Enabled = false;
            txthora.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            
            if(txtnombre.Text.Length == 0 || txtnacimiento.Text.Length == 0 || txtcorreo.Text.Length == 0 || txtcorreo.Text.Length == 0 || txtcelular.Text.Length == 0 || txtmatricula.Text.Length ==0)
            {
                MessageBox.Show("Error: Rellene los todos los campos, para iniciar","Error al iniciar Test", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

            }
            else
            {
                Encuestado Enc = new Encuestado();
                Enc.Matricula = Convert.ToInt32(txtmatricula.Text.Trim());
                int matricula = Convert.ToInt32(txtmatricula.Text.Trim());
                Enc.Nombre = txtnombre.Text.Trim();
                Enc.Fechaacimiento = txtnacimiento.Text;
                Enc.Correo = txtcorreo.Text.Trim();
                Enc.Celular = Convert.ToInt64(txtcelular.Text.Trim());
                Enc.FechaAplicacion = DateTime.Now.ToString("yyyy-MM-dd");
                Enc.Hora = fechahoy.ToShortTimeString();

                

                int resultado = EncuestadoDAO.Agregar(Enc);
                if (resultado > 0)
                {
                    MessageBox.Show("Registro Exitoso!!", "Iniciemos!", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("La matricula ya esta siendo usada", "No se pudo registrar correctamente!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Exclamation);
                }

                Encuesta1 primerencuesta = new Encuesta1(matricula);
                primerencuesta.Show();
                this.Hide();
            }
            

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            Modifica1 m1 = new Modifica1();
            m1.Show();
            this.Hide();
        }
    }
}
