﻿namespace Test_Inteligencias_Multiples_2
{
    partial class ResultadoModificado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.txtrespuesta1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.destaca = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.datos = new Test_Inteligencias_Multiples_2.datos();
            this.testexamenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testexamenTableAdapter = new Test_Inteligencias_Multiples_2.datosTableAdapters.testexamenTableAdapter();
            this.tableAdapterManager = new Test_Inteligencias_Multiples_2.datosTableAdapters.TableAdapterManager();
            this.matriculaTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(699, 125);
            this.chart1.Name = "chart1";
            this.chart1.Size = new System.Drawing.Size(300, 300);
            this.chart1.TabIndex = 18;
            this.chart1.Text = "chart1";
            this.chart1.Click += new System.EventHandler(this.chart1_Click);
            // 
            // txtrespuesta1
            // 
            this.txtrespuesta1.AutoSize = true;
            this.txtrespuesta1.Depth = 0;
            this.txtrespuesta1.Font = new System.Drawing.Font("Roboto", 11F);
            this.txtrespuesta1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtrespuesta1.Location = new System.Drawing.Point(594, 206);
            this.txtrespuesta1.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtrespuesta1.Name = "txtrespuesta1";
            this.txtrespuesta1.Size = new System.Drawing.Size(18, 19);
            this.txtrespuesta1.TabIndex = 17;
            this.txtrespuesta1.Text = "#";
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(555, 178);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(94, 19);
            this.materialLabel1.TabIndex = 16;
            this.materialLabel1.Text = "Contestadas";
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(126, 307);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(328, 69);
            this.materialRaisedButton1.TabIndex = 14;
            this.materialRaisedButton1.Text = "Salir";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // destaca
            // 
            this.destaca.AutoSize = true;
            this.destaca.BackColor = System.Drawing.Color.SpringGreen;
            this.destaca.Font = new System.Drawing.Font("MS Reference Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.destaca.Location = new System.Drawing.Point(120, 191);
            this.destaca.Name = "destaca";
            this.destaca.Size = new System.Drawing.Size(378, 34);
            this.destaca.TabIndex = 13;
            this.destaca.Text = "Multiples Inteligencias :o";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(103, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(448, 34);
            this.label1.TabIndex = 11;
            this.label1.Text = "Nueva Inteligencia Modificada";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(76, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(519, 34);
            this.label2.TabIndex = 12;
            this.label2.Text = "____________________________";
            // 
            // datos
            // 
            this.datos.DataSetName = "datos";
            this.datos.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // testexamenBindingSource
            // 
            this.testexamenBindingSource.DataMember = "testexamen";
            this.testexamenBindingSource.DataSource = this.datos;
            // 
            // testexamenTableAdapter
            // 
            this.testexamenTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.testexamenTableAdapter = this.testexamenTableAdapter;
            this.tableAdapterManager.UpdateOrder = Test_Inteligencias_Multiples_2.datosTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // matriculaTextBox
            // 
            this.matriculaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.testexamenBindingSource, "matricula", true));
            this.matriculaTextBox.Location = new System.Drawing.Point(12, 75);
            this.matriculaTextBox.Name = "matriculaTextBox";
            this.matriculaTextBox.Size = new System.Drawing.Size(100, 20);
            this.matriculaTextBox.TabIndex = 20;
            // 
            // ResultadoModificado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 534);
            this.Controls.Add(this.matriculaTextBox);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.txtrespuesta1);
            this.Controls.Add(this.materialLabel1);
            this.Controls.Add(this.materialRaisedButton1);
            this.Controls.Add(this.destaca);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Name = "ResultadoModificado";
            this.Text = "ResultadoModificado";
            this.Load += new System.EventHandler(this.ResultadoModificado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testexamenBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private MaterialSkin.Controls.MaterialLabel txtrespuesta1;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
        private System.Windows.Forms.Label destaca;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private datos datos;
        private System.Windows.Forms.BindingSource testexamenBindingSource;
        private datosTableAdapters.testexamenTableAdapter testexamenTableAdapter;
        private datosTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox matriculaTextBox;
    }
}