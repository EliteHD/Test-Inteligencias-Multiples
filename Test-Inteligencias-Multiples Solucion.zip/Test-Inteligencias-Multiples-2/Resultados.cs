﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class Resultados
    {
        public string Resultado { get; set; }
        public int Matricula { get; set; }
        public Resultados() { }
        public Resultados(string Resultado,int Matricula)
        {
            this.Resultado = Resultado;
            this.Matricula = Matricula;
        }
    }
}
