﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Test_Inteligencias_Multiples_2
{
    public partial class ResultadosTest : MaterialSkin.Controls.MaterialForm
    {
        public ResultadosTest(int resustados1, int resustados2, int resustados3, int resustados4, int resustados5, int resustados6, int resustados7, int resustados8,int matricula)
        {
            InitializeComponent();
            this.resultados1 = resustados1;
            this.resultados2 = resustados2;
            this.resultados3 = resustados3;
            this.resultados4 = resustados4;
            this.resultados5 = resustados5;
            this.resultados6 = resustados6;
            this.resultados7 = resustados7;
            this.resultados8 = resustados8;
            this.matricula = matricula;
        }
        int matricula;
        int resultados1;
        int resultados2, resultados3, resultados4, resultados5, resultados6, resultados7, resultados8;

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
            Registro inicio = new Registro();
            inicio.Show();
            this.Hide();
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ResultadosTest_Load(object sender, EventArgs e)
        {
            if( resultados1 > resultados2 && resultados1 > resultados3 && resultados1 > resultados4 && resultados1 > resultados5 && resultados1 > resultados6 && resultados1 > resultados7 && resultados1 > resultados8)
            {
                destaca.Text = "Inteligencia verbal lingüistica";
                txtrespuesta1.Text = Convert.ToString(resultados1);

            }
            
            if (resultados2 > resultados1 && resultados2 > resultados3 && resultados2 > resultados4 && resultados2 > resultados5 && resultados2 > resultados6 && resultados2 > resultados7 && resultados2 > resultados8)
            {
                destaca.Text = "Inteligencia lógico-matemática";
                txtrespuesta1.Text = Convert.ToString(resultados2);

            }
           
            if (resultados3 > resultados2 && resultados3 > resultados1 && resultados3 > resultados4 && resultados3 > resultados5 && resultados3 > resultados6 && resultados3 > resultados7 && resultados3 > resultados8)
            {
                destaca.Text = "Inteligencia visio-espacial";
                txtrespuesta1.Text = Convert.ToString(resultados3);

            }
            

            if (resultados4 > resultados2 && resultados4 > resultados3 && resultados4 > resultados1 && resultados4 > resultados5 && resultados4 > resultados6 && resultados4 > resultados7 && resultados4 > resultados8)
            {
                destaca.Text = "Inteligencia cinético-corporal";
                txtrespuesta1.Text = Convert.ToString(resultados4);

            }
            

            if (resultados5 > resultados2 && resultados5 > resultados3 && resultados5 > resultados4 && resultados5 > resultados1 && resultados5 > resultados6 && resultados5 > resultados7 && resultados5 > resultados8)
            {
                destaca.Text = "Inteligencia musical";
                txtrespuesta1.Text = Convert.ToString(resultados5);


            }
            

            if (resultados6 > resultados2 && resultados6 > resultados3 && resultados6 > resultados4 && resultados6 > resultados5 && resultados6 > resultados1 && resultados6 > resultados7 && resultados6 > resultados8)
            {
                destaca.Text = "Inteligencia interpersonal";
                txtrespuesta1.Text = Convert.ToString(resultados6);


            }
            
            if (resultados7 > resultados2 && resultados7 > resultados3 && resultados7 > resultados4 && resultados7 > resultados5 && resultados7 > resultados6 && resultados7 > resultados1 && resultados7 > resultados8)
            {
                destaca.Text = "Inteligencia intrapersonal";
                txtrespuesta1.Text = Convert.ToString(resultados7);


            }
            
            if (resultados8 > resultados2 && resultados8 > resultados3 && resultados8 > resultados4 && resultados8 > resultados5 && resultados8 > resultados6 && resultados8 > resultados7 && resultados8 > resultados1)
            {
                destaca.Text = "Inteligencia naturalista";
                txtrespuesta1.Text = Convert.ToString(resultados8);


            }

            string[] secciones = {"Verbal Linguistica","Lógico-Matemático","Visio-Espacial","Cinético-Corporal","Musical","Interpersonal","Intrapersonal","Naturalista"};
            int[] resultados = { resultados1, resultados2, resultados3, resultados4, resultados5, resultados6, resultados7, resultados8 };

            chart1.Palette = ChartColorPalette.Pastel;

            chart1.Titles.Add("Inteligencias Multiples");

            for(int i = 0; i<secciones.Length; i++)
            {
                Series tablas = chart1.Series.Add(secciones[i]);

                tablas.Label = resultados[i].ToString();

                tablas.Points.Add(resultados[i]);

            }

            Resultados rr = new Resultados();
            rr.Matricula = matricula;
            rr.Resultado = destaca.Text;


            int resultado = EncuestadoDAO.Resultadost(rr);
            if (resultado > 0)
            {
                MessageBox.Show("Que te parece? ", "Test Completado! ", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Uy! parece que hubo un error", "Fallo!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }
        }
    }
}
