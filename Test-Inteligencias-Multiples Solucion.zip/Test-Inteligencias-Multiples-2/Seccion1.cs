﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class Seccion1
    {
        public int Matricula { get; set; }
        public bool p1_s1 { get; set; }
        public bool p2_s1 { get; set; }
        public bool p3_s1 { get; set; }
        public bool p4_s1 { get; set; }
        public bool p5_s1 { get; set; }
        public bool p6_s1 { get; set; }
        public bool p7_s1 { get; set; }
        public bool p8_s1 { get; set; }
        public bool p9_s1 { get; set; }
        public bool p10_s1 { get; set; }

        public Seccion1() { }
        public Seccion1(int Matricula, bool p1_s1, bool p2_s1, bool p3_s1, bool p4_s1, bool p5_s1, bool p6_s1, bool p7_s1, bool p8_s1, bool p9_s1, bool p10_s1)
        {
            this.Matricula = Matricula;
            this.p1_s1 = p1_s1;
            this.p2_s1 = p2_s1;
            this.p3_s1 = p3_s1;
            this.p4_s1 = p4_s1;
            this.p5_s1 = p5_s1;
            this.p6_s1 = p6_s1;
            this.p7_s1 = p7_s1;
            this.p8_s1 = p8_s1;
            this.p9_s1 = p9_s1;
            this.p10_s1 = p10_s1;
        }
    }
}
