﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class Seccion2
    {
        public int Matricula { get; set; }
        public bool p1_s2 { get; set; }
        public bool p2_s2 { get; set; }
        public bool p3_s2 { get; set; }
        public bool p4_s2 { get; set; }
        public bool p5_s2 { get; set; }
        public bool p6_s2 { get; set; }
        public bool p7_s2 { get; set; }
        public bool p8_s2 { get; set; }
        public bool p9_s2 { get; set; }
        public bool p10_s2 { get; set; }

        public Seccion2() { }
        public Seccion2(int Matricula,bool p1_s2, bool p2_s2, bool p3_s2, bool p4_s2, bool p5_s2, bool p6_s2, bool p7_s2, bool p8_s2, bool p9_s2, bool p10_s2)
        {
            this.Matricula = Matricula;

            this.p1_s2 = p1_s2;
            this.p2_s2 = p2_s2;
            this.p3_s2 = p3_s2;
            this.p4_s2 = p4_s2;
            this.p5_s2 = p5_s2;
            this.p6_s2 = p6_s2;
            this.p7_s2 = p7_s2;
            this.p8_s2 = p8_s2;
            this.p9_s2 = p9_s2;
            this.p10_s2 = p10_s2;
        }
    }
}
