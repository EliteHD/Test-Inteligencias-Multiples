﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class Seccion3
    {
        public int Matricula { get; set; }
        public bool p1_s3 { get; set; }
        public bool p2_s3 { get; set; }
        public bool p3_s3 { get; set; }
        public bool p4_s3 { get; set; }
        public bool p5_s3 { get; set; }
        public bool p6_s3 { get; set; }
        public bool p7_s3 { get; set; }
        public bool p8_s3 { get; set; }
        public bool p9_s3 { get; set; }
        public bool p10_s3 { get; set; }
        public Seccion3() { }
        public Seccion3(int Matricula, bool p1_s3, bool p2_s3, bool p3_s3, bool p4_s3, bool p5_s3, bool p6_s3, bool p7_s3, bool p8_s3, bool p9_s3, bool p10_s3)
        {
            this.Matricula = Matricula;

            this.p1_s3 = p1_s3;
            this.p2_s3 = p2_s3;
            this.p3_s3 = p3_s3;
            this.p4_s3 = p4_s3;
            this.p5_s3 = p5_s3;
            this.p6_s3 = p6_s3;
            this.p7_s3 = p7_s3;
            this.p8_s3 = p8_s3;
            this.p9_s3 = p9_s3;
            this.p10_s3 = p10_s3;
        }
    }
}
