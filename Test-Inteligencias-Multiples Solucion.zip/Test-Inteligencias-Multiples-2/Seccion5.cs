﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class Seccion5
    {
        public int Matricula { get; set; }
        public bool p1_s5 { get; set; }
        public bool p2_s5 { get; set; }
        public bool p3_s5 { get; set; }
        public bool p4_s5 { get; set; }
        public bool p5_s5 { get; set; }
        public bool p6_s5 { get; set; }
        public bool p7_s5 { get; set; }
        public bool p8_s5 { get; set; }
        public bool p9_s5 { get; set; }
        public bool p10_s5 { get; set; }
        public Seccion5() { }
        public Seccion5(int Matricula, bool p1_s5, bool p2_s5, bool p3_s5, bool p4_s5, bool p5_s5, bool p6_s5, bool p7_s5, bool p8_s5, bool p9_s5, bool p10_s5)
        {
            this.Matricula = Matricula;

            this.p1_s5 = p1_s5;
            this.p2_s5 = p2_s5;
            this.p3_s5 = p3_s5;
            this.p4_s5 = p4_s5;
            this.p5_s5 = p5_s5;
            this.p6_s5 = p6_s5;
            this.p7_s5 = p7_s5;
            this.p8_s5 = p8_s5;
            this.p9_s5 = p9_s5;
            this.p10_s5 = p10_s5;
        }
    }
}
