﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class Seccion6
    {
        public int Matricula { get; set; }
        public bool p1_s6 { get; set; }
        public bool p2_s6 { get; set; }
        public bool p3_s6 { get; set; }
        public bool p4_s6 { get; set; }
        public bool p5_s6 { get; set; }
        public bool p6_s6 { get; set; }
        public bool p7_s6 { get; set; }
        public bool p8_s6 { get; set; }
        public bool p9_s6 { get; set; }
        public bool p10_s6 { get; set; }
        public Seccion6(int Matricula,bool p1_s6, bool p2_s6, bool p3_s6, bool p4_s6, bool p5_s6, bool p6_s6, bool p7_s6, bool p8_s6, bool p9_s6, bool p10_s6)
        {
            this.Matricula = Matricula;

            this.p1_s6 = p1_s6;
            this.p2_s6 = p2_s6;
            this.p3_s6 = p3_s6;
            this.p4_s6 = p4_s6;
            this.p5_s6 = p5_s6;
            this.p6_s6 = p6_s6;
            this.p7_s6 = p7_s6;
            this.p8_s6 = p8_s6;
            this.p9_s6 = p9_s6;
            this.p10_s6 = p10_s6;
        }
        public Seccion6() { }
    }
}
