﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class Seccion7
    {
        public int Matricula { get; set; }
        public bool p1_s7 { get; set; }
        public bool p2_s7 { get; set; }
        public bool p3_s7 { get; set; }
        public bool p4_s7 { get; set; }
        public bool p5_s7 { get; set; }
        public bool p6_s7 { get; set; }
        public bool p7_s7 { get; set; }
        public bool p8_s7 { get; set; }
        public bool p9_s7 { get; set; }
        public bool p10_s7 { get; set; }
        public Seccion7(int Matricula,bool p1_s7, bool p2_s7, bool p3_s7, bool p4_s7, bool p5_s7, bool p6_s7, bool p7_s7, bool p8_s7, bool p9_s7, bool p10_s7)
        {
            this.Matricula = Matricula;

            this.p1_s7 = p1_s7;
            this.p2_s7 = p2_s7;
            this.p3_s7 = p3_s7;
            this.p4_s7 = p4_s7;
            this.p5_s7 = p5_s7;
            this.p6_s7 = p6_s7;
            this.p7_s7 = p7_s7;
            this.p8_s7 = p8_s7;
            this.p9_s7 = p9_s7;
            this.p10_s7 = p10_s7;
        }
        public Seccion7() { }
    }
}
