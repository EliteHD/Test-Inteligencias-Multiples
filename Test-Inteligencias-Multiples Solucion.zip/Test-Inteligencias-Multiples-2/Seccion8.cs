﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Inteligencias_Multiples_2
{
    internal class Seccion8
    {
        public int Matricula { get; set; }
        public bool p1_s8 { get; set; }
        public bool p2_s8 { get; set; }
        public bool p3_s8 { get; set; }
        public bool p4_s8 { get; set; }
        public bool p5_s8 { get; set; }
        public bool p6_s8 { get; set; }
        public bool p7_s8 { get; set; }
        public bool p8_s8 { get; set; }
        public bool p9_s8 { get; set; }
        public bool p10_s8 { get; set; }
        public Seccion8(int Matricula,bool p1_s8, bool p2_s8, bool p3_s8, bool p4_s8, bool p5_s8, bool p6_s8, bool p7_s8, bool p8_s8, bool p9_s8, bool p10_s8)
        {
            this.Matricula = Matricula;

            this.p1_s8 = p1_s8;
            this.p2_s8 = p2_s8;
            this.p3_s8 = p3_s8;
            this.p4_s8 = p4_s8;
            this.p5_s8 = p5_s8;
            this.p6_s8 = p6_s8;
            this.p7_s8 = p7_s8;
            this.p8_s8 = p8_s8;
            this.p9_s8 = p9_s8;
            this.p10_s8 = p10_s8;
        }
        public Seccion8() { }
    }
}
