﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Test_Inteligencias_Multiples_2
{
    internal class bdCon
    {
        public static NpgsqlConnection ObtenerConexion()
        {

            NpgsqlConnection conectar = new NpgsqlConnection("Server=localhost;Port=5432;User Id=postgres;Password=Dnersin1hd;Database=examenInteligencia");//Encrypt=False;
            conectar.Open();
            return conectar;

        }
        public static NpgsqlConnection CerrarConexion()
        {
            NpgsqlConnection desconectar = new NpgsqlConnection("Server = localhost; Port = 5432; User Id = postgres; Password = Dnersin1hd; Database = examenInteligencia");
            desconectar.Close();
            return desconectar;
        }
    }
}
